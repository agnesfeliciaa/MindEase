package com.example.kelompokmindease_3tia.basic_api.ui.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_api.data.model.ArtikelTerkaitModel
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.artikel.ArtikelWebViewActivity
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.meditasi.PutarDiriyangLebihBaikActivity
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.meditasi.PutarStressdanKecemasanActivity
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.meditasi.PutarTidurLebihNyenyakActivity
import com.example.kelompokmindease_3tia.databinding.ArtikelTerkaitItemBinding
import com.squareup.picasso.Picasso

class ArtikelTerkaitAdapter (
//    private val mList:List<HomeNewsHorizontalModel>
    private var mList:List<ArtikelTerkaitModel>,
    private val onItemClick: (String) -> Unit

): RecyclerView.Adapter<ArtikelTerkaitAdapter.ViewHolder>(){


    fun updateData(newItems: List<ArtikelTerkaitModel>){
        mList = newItems
        notifyDataSetChanged()
    }

    class ViewHolder(val binding: ArtikelTerkaitItemBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val  binding= ArtikelTerkaitItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = mList[position]

        // Cek tipe `imagaUrl` untuk menentukan cara memuat gambar
        if (item.imageUrl is String) {
            // Memuat URL eksternal dengan Picasso
            Picasso.get().load(item.imageUrl as String).into(holder.binding.imgTerkait)
        } else if (item.imageUrl is Int) {
            // Memuat resource drawable lokal
            holder.binding.imgTerkait.setImageResource(item.imageUrl as Int)
        }

        holder.binding.judulTerkait.text = item.judul
        holder.binding.tanggalTerkait.text = item.tanggal
        holder.binding.dilihatTerkait.text = item.menit

        // Menangani klik pada item untuk membuka URL
        holder.binding.root.setOnClickListener {
            onItemClick(item.url)  // Mengirim URL ke callback untuk membuka WebView
        }

    }

    override fun getItemCount(): Int {
        return mList.size
    }
}