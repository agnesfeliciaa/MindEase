package com.example.kelompokmindease_3tia.basic_api.ui.view.main.meditasi

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_api.data.model.MeditasiModel
import com.example.kelompokmindease_3tia.databinding.FragmentMeditasiFokusBinding
import com.example.kelompokmindease_3tia.basic_api.ui.adapter.MeditasiAdapter

class MeditasiFokusFragment : Fragment() {

    private var _binding : FragmentMeditasiFokusBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentMeditasiFokusBinding.inflate(inflater, container, false)

        setUpNewsHorizontal(binding)

        return binding.root
    }

    private fun setUpNewsHorizontal(binding: FragmentMeditasiFokusBinding){
//    private fun setUpNewsHorizontal(view:View){
//        val newsHorizontal:RecyclerView = view.findViewById(R.id.newsHorizontalList)
        val items = listOf(
            MeditasiModel(R.drawable.g_meditasi2, "Stress dan Kecemasan", "4 Menit"),
        )

        binding.recyclerViewMeditasi.adapter = MeditasiAdapter(items)
        binding.recyclerViewMeditasi.layoutManager = LinearLayoutManager(requireContext())
    }
}