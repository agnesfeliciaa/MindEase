package com.example.kelompokmindease_3tia.basic_api.data.model

data class NewsHoriModel (
    val newsTitle: String,
    val imageUrl: String
)