package com.example.kelompokmindease_3tia.basic_api.ui.view.main.survey.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_api.ui.viewmodel.SurveyViewModel
import com.example.kelompokmindease_3tia.basic_fragment.FragmentActivity
import com.example.kelompokmindease_3tia.databinding.FragmentSurvey5Binding
import com.example.kelompokmindease_3tia.databinding.FragmentSurvey9Binding

class Survey9Fragment : Fragment() {

    private var _binding: FragmentSurvey9Binding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: SurveyViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSurvey9Binding.inflate(inflater, container, false)

        // Inisialisasi ViewModel
        viewModel = ViewModelProvider(requireActivity()).get(SurveyViewModel::class.java)

        binding.buttonNext.setOnClickListener {
            val input = binding.basicNeeds.text.toString()

            if (input.isNotEmpty()) {
                val number = input.toIntOrNull()
                if (number == null) {
                    Toast.makeText(requireContext(), "Masukkan angka yang valid", Toast.LENGTH_SHORT).show()
                } else if (number < 0 || number > 5) {
                    Toast.makeText(requireContext(), "Isi sesuai rentang (0-5)", Toast.LENGTH_SHORT).show()
                } else {
                    // Simpan input ke ViewModel dengan key "basic_needs"
                    viewModel.setAnswer("basic_needs", number)

                    // Navigasi ke Survey10Fragment
                    (activity as? SurveyActivity)?.replaceFragment(Survey10Fragment())
                }
            } else {
                Toast.makeText(requireContext(), "Isi inputan", Toast.LENGTH_SHORT).show()
            }
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
