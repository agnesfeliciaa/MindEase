package com.example.kelompokmindease_3tia.basic_api.ui.view.main

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_fragment.FragmentInsight
import com.example.kelompokmindease_3tia.basic_fragment.FragmentMeditation
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.artikel.ArtikelFragment
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.home.Home2Fragment
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.meditasi.MeditasiFragment
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.more.MoreFragment
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.profile.ProfileFragment
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.survey.SurveyFragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, 0)
            insets
        }

        loadFragment(Home2Fragment())

        val bottomNav : BottomNavigationView = findViewById(R.id.bottom_nav_view)
        bottomNav.setOnItemSelectedListener{
            when (it.itemId) {
                R.id.home -> {
                    loadFragment(Home2Fragment())
                }

                R.id.survey -> {
                    loadFragment(SurveyFragment())
                }

                R.id.meditation -> {
                    loadFragment(MeditasiFragment())
                }

                R.id.artikel -> {
                    loadFragment(ArtikelFragment())
                }
//
                R.id.profile -> {
                    loadFragment(ProfileFragment())
                }
            }
            true
        }
    }
    private fun loadFragment(fragment: Fragment){
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.fragment_container, fragment)
        transaction.commit()
    }
}