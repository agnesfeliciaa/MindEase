package com.example.kelompokmindease_3tia.basic_api.ui.view.main.profile

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import com.example.kelompokmindease_3tia.R



class EditProfileActivity : AppCompatActivity() {

    private lateinit var imgPP: ImageView
    private lateinit var btnBack: ImageView
    private lateinit var btnPilih: Button
    private lateinit var cardMenu1: CardView
    private lateinit var cardMenu2: CardView
    private lateinit var cardMenu3: CardView
    private lateinit var cardMenu4: CardView
    private lateinit var cardMenu5: CardView
    private lateinit var cardMenu6: CardView
    private lateinit var cardMenu7: CardView
    private lateinit var cardMenu8: CardView
    private lateinit var cardMenu9: CardView
    private lateinit var cardMenu10: CardView
    private lateinit var cardMenu11: CardView
    private lateinit var cardMenu12: CardView
    private lateinit var cardMenu13: CardView
    private lateinit var cardMenu14: CardView
    private lateinit var cardMenu15: CardView
    private lateinit var cardMenu16: CardView
    private lateinit var cardMenu17: CardView
    private lateinit var cardMenu18: CardView

    private var selectedImage: Int = -1  // Variabel untuk menyimpan gambar yang dipilih

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        // Inisialisasi view
        imgPP = findViewById(R.id.imgPP)
        btnBack = findViewById(R.id.btnBack)
        btnPilih = findViewById(R.id.btnPilih)
        cardMenu1 = findViewById(R.id.cardMenu1)
        cardMenu2 = findViewById(R.id.cardMenu2)
        cardMenu3 = findViewById(R.id.cardMenu3)
        cardMenu4 = findViewById(R.id.cardMenu4)
        cardMenu5 = findViewById(R.id.cardMenu5)
        cardMenu6 = findViewById(R.id.cardMenu6)
        cardMenu7 = findViewById(R.id.cardMenu7)
        cardMenu8 = findViewById(R.id.cardMenu8)
        cardMenu9 = findViewById(R.id.cardMenu9)
        cardMenu10 = findViewById(R.id.cardMenu10)
        cardMenu11 = findViewById(R.id.cardMenu11)
        cardMenu12 = findViewById(R.id.cardMenu12)
        cardMenu13 = findViewById(R.id.cardMenu13)
        cardMenu14 = findViewById(R.id.cardMenu14)
        cardMenu15 = findViewById(R.id.cardMenu15)
        cardMenu16 = findViewById(R.id.cardMenu16)
        cardMenu17 = findViewById(R.id.cardMenu17)
        cardMenu18 = findViewById(R.id.cardMenu18)


        // Muat gambar terakhir dari SharedPreferences
        loadLastSelectedImage()

        // Menambahkan listener untuk tombol kembali
        btnBack.setOnClickListener {
            finish()
        }

        // Menambahkan listener untuk cardMenu1
        cardMenu1.setOnClickListener {
            // Set gambar yang dipilih
            selectedImage = R.drawable.g_profile1
            showConfirmationDialog(R.drawable.g_profile1)
        }

        // Menambahkan listener untuk cardMenu2
        cardMenu2.setOnClickListener {
            // Set gambar yang dipilih
            selectedImage = R.drawable.g_profile2
            showConfirmationDialog(R.drawable.g_profile2) // Tampilkan dialog konfirmasi
        }

        // Menambahkan listener untuk cardMenu3
        cardMenu3.setOnClickListener {
            // Set gambar yang dipilih
            selectedImage = R.drawable.g_profile3
            showConfirmationDialog(R.drawable.g_profile3) // Tampilkan dialog konfirmasi
        }

        // Menambahkan listener untuk cardMenu4
        cardMenu4.setOnClickListener {
            // Set gambar yang dipilih
            selectedImage = R.drawable.g_profile4
            showConfirmationDialog(R.drawable.g_profile4) // Tampilkan dialog konfirmasi
        }

        // Menambahkan listener untuk cardMenu5
        cardMenu5.setOnClickListener {
            // Set gambar yang dipilih
            selectedImage = R.drawable.g_profile5
            showConfirmationDialog(R.drawable.g_profile5) // Tampilkan dialog konfirmasi
        }

        // Menambahkan listener untuk cardMenu6
        cardMenu6.setOnClickListener {
            // Set gambar yang dipilih
            selectedImage = R.drawable.g_profile6
            showConfirmationDialog(R.drawable.g_profile6) // Tampilkan dialog konfirmasi
        }

        // Menambahkan listener untuk cardMenu7
        cardMenu7.setOnClickListener {
            // Set gambar yang dipilih
            selectedImage = R.drawable.g_profile7
            showConfirmationDialog(R.drawable.g_profile7) // Tampilkan dialog konfirmasi
        }

        // Menambahkan listener untuk cardMenu8
        cardMenu8.setOnClickListener {
            // Set gambar yang dipilih
            selectedImage = R.drawable.g_profile8
            showConfirmationDialog(R.drawable.g_profile8) // Tampilkan dialog konfirmasi
        }

        // Menambahkan listener untuk cardMenu9
        cardMenu9.setOnClickListener {
            // Set gambar yang dipilih
            selectedImage = R.drawable.g_profile9
            showConfirmationDialog(R.drawable.g_profile9) // Tampilkan dialog konfirmasi
        }

        // Menambahkan listener untuk cardMenu10
        cardMenu10.setOnClickListener {
            // Set gambar yang dipilih
            selectedImage = R.drawable.g_profile10
            showConfirmationDialog(R.drawable.g_profile10) // Tampilkan dialog konfirmasi
        }

        // Menambahkan listener untuk cardMenu11
        cardMenu11.setOnClickListener {
            // Set gambar yang dipilih
            selectedImage = R.drawable.g_profile11
            showConfirmationDialog(R.drawable.g_profile11) // Tampilkan dialog konfirmasi
        }

        // Menambahkan listener untuk cardMenu12
        cardMenu12.setOnClickListener {
            // Set gambar yang dipilih
            selectedImage = R.drawable.g_profile12
            showConfirmationDialog(R.drawable.g_profile12) // Tampilkan dialog konfirmasi
        }

        // Menambahkan listener untuk cardMenu13
        cardMenu13.setOnClickListener {
            // Set gambar yang dipilih
            selectedImage = R.drawable.g_profile13
            showConfirmationDialog(R.drawable.g_profile13) // Tampilkan dialog konfirmasi
        }

        // Menambahkan listener untuk cardMenu14
        cardMenu14.setOnClickListener {
            // Set gambar yang dipilih
            selectedImage = R.drawable.g_profile14
            showConfirmationDialog(R.drawable.g_profile14) // Tampilkan dialog konfirmasi
        }

        // Menambahkan listener untuk cardMenu15
        cardMenu15.setOnClickListener {
            // Set gambar yang dipilih
            selectedImage = R.drawable.g_profile15
            showConfirmationDialog(R.drawable.g_profile15) // Tampilkan dialog konfirmasi
        }

        // Menambahkan listener untuk cardMenu16
        cardMenu16.setOnClickListener {
            // Set gambar yang dipilih
            selectedImage = R.drawable.g_profile16
            showConfirmationDialog(R.drawable.g_profile16) // Tampilkan dialog konfirmasi
        }

        // Menambahkan listener untuk cardMenu17
        cardMenu17.setOnClickListener {
            // Set gambar yang dipilih
            selectedImage = R.drawable.g_profile17
            showConfirmationDialog(R.drawable.g_profile17) // Tampilkan dialog konfirmasi
        }

        // Menambahkan listener untuk cardMenu18
        cardMenu18.setOnClickListener {
            // Set gambar yang dipilih
            selectedImage = R.drawable.g_profile18
            showConfirmationDialog(R.drawable.g_profile18) // Tampilkan dialog konfirmasi
        }


        // Menambahkan listener untuk tombol pilih
        btnPilih.setOnClickListener {
            if (selectedImage != -1) {
                saveSelectedImageToPreferences(selectedImage)
                Toast.makeText(this, "Gambar berhasil disimpan!", Toast.LENGTH_SHORT).show()
                finish() // Kembali ke activity/fragment sebelumnya
            } else {
                Toast.makeText(this, "Pilih gambar terlebih dahulu", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Fungsi untuk menyimpan gambar yang dipilih ke SharedPreferences
    private fun saveSelectedImageToPreferences(imageResId: Int) {
        val sharedPreferences = getSharedPreferences("ProfilePrefs", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putInt("selectedImage", imageResId)
        editor.apply()
    }
    // Fungsi untuk memuat gambar terakhir dari SharedPreferences
    private fun loadLastSelectedImage() {
        val sharedPreferences = getSharedPreferences("ProfilePrefs", Context.MODE_PRIVATE)
        val lastSelectedImage = sharedPreferences.getInt("selectedImage", -1)

        if (lastSelectedImage != -1) {
            imgPP.setImageResource(lastSelectedImage) // Atur gambar terakhir ke imgPP
            selectedImage = lastSelectedImage // Tetapkan sebagai gambar yang dipilih saat ini
        }
    }

    // Fungsi untuk menampilkan dialog konfirmasi
    private fun showConfirmationDialog(imageResId: Int) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Konfirmasi")
            .setMessage("Yakin ingin memilih avatar ini?")
            .setPositiveButton("Ya") { _, _ ->
                imgPP.setImageResource(imageResId)
            }
            .setNegativeButton("Batal", null)

        val dialog = builder.create()
        dialog.show()
    }
}