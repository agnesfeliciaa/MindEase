package com.example.kelompokmindease_3tia.basic_api.ui.viewmodel

import androidx.lifecycle.ViewModel

class SurveyViewModel : ViewModel() {
    val surveyAnswers = mutableMapOf<String, Int>()

    fun setAnswer(key: String, value: Int) {
        surveyAnswers[key] = value
    }
    fun getAllAnswers(): Map<String, Int> {
        return surveyAnswers
    }

}
