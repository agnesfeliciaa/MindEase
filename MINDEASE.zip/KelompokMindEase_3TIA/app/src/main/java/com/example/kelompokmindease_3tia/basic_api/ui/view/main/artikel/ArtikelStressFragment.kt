package com.example.kelompokmindease_3tia.basic_api.ui.view.main.artikel

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_api.data.model.ArtikelRequest
import com.example.kelompokmindease_3tia.basic_api.data.model.ArtikelTerkaitModel
import com.example.kelompokmindease_3tia.basic_api.data.network.RetrofitInstance
import com.example.kelompokmindease_3tia.basic_api.data.repository.ArtikelRepository
import com.example.kelompokmindease_3tia.basic_api.ui.adapter.ArtikelTerkaitAdapter
import com.example.kelompokmindease_3tia.basic_api.ui.viewmodel.ArtikelViewModel
import com.example.kelompokmindease_3tia.basic_api.utils.Resource
import com.example.kelompokmindease_3tia.basic_api.utils.ViewModelFactory
import com.example.kelompokmindease_3tia.databinding.FragmentArtikelStressBinding
import com.google.android.material.snackbar.Snackbar

class ArtikelStressFragment : Fragment() {
    private var _binding: FragmentArtikelStressBinding? = null
    private val binding get() = _binding!!

    private val artikelViewModel: ArtikelViewModel by activityViewModels {
        ViewModelFactory(ArtikelViewModel::class.java) {
            val repository = ArtikelRepository(
                RetrofitInstance.getCrudApi()
            )
            ArtikelViewModel(repository)
        }
    }

    private lateinit var adapter: ArtikelTerkaitAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentArtikelStressBinding.inflate(inflater, container, false)

        //adapter = ArtikelTerkaitAdapter(emptyList())
        adapter = ArtikelTerkaitAdapter(emptyList()) { url ->
            if (url.isValidUrl()) {
                openWebViewActivity(url)
            } else {
                Toast.makeText(requireContext(), "URL tidak valid", Toast.LENGTH_SHORT).show()
            }
        }

        binding.artikelList.adapter = adapter
        binding.artikelList.layoutManager = LinearLayoutManager(requireContext())

//        setUpPopulerHorizontal(binding)
//        setUpTrendingHorizontal(binding)
        setUpTerkait(binding)
        getArtikel()
        //createArtikel()

        return binding.root
    }

    private fun setUpTerkait(binding: FragmentArtikelStressBinding) {
        val items = listOf(
            ArtikelTerkaitModel(
                R.drawable.g_artikel_terkait1,
                "Tips and Trick Mengurangi Stress",
                "Jun 10, 2024 ",
                "5 min dilihat",
                "https://prodia.co.id/id/artikel-detail/9-cara-mengatasi-stres-secara-efektif"
            ),
            ArtikelTerkaitModel(
                R.drawable.g_artikel_terkait2,
                "Meditasi untuk Mengatasi Stres dan Penyakit ",
                "Jun 9, 2024 ",
                "8 min dilihat",
                "https://www.alodokter.com/sering-sakit-dan-stres-coba-meditasi"
            ),
            ArtikelTerkaitModel(
                R.drawable.g_artikel_terkait3,
                "Pembelajaran Jarak Jauh bisa membuat stress?",
                "Des 10, 2024 ",
                "12 min read",
                "https://rsmmbogor.com/anak-stres-saat-belajar-online-kenali-dan-atasi-gejalanya595Ij9"
            ),
        )
        binding.artikelList.adapter = ArtikelTerkaitAdapter(items) { url ->
            if (url.isValidUrl()) {
                openWebViewActivity(url)
            } else {
                Toast.makeText(requireContext(), "URL tidak valid", Toast.LENGTH_SHORT).show()
            }
        }

        binding.artikelList.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
    }

    private fun openWebViewActivity(url: String) {
        try {
            val intent = Intent(requireContext(), ArtikelWebViewActivity::class.java).apply {
                putExtra("url", url)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Log.e("ArtikelStressFragment", "Error membuka WebView Activity: ${e.message}")
            Toast.makeText(requireContext(), "Gagal membuka artikel", Toast.LENGTH_SHORT).show()
        }
    }


    private fun String.isValidUrl(): Boolean {
        return Patterns.WEB_URL.matcher(this).matches()
    }


    private fun getArtikel() {
        artikelViewModel.getArtikels(requireContext())
        artikelViewModel.data.observe(viewLifecycleOwner) { resource ->
            //if (!isAdded) return@observe // Pastikan fragment masih aktif
            when (resource) {
                is Resource.Loading -> {
                    Log.d("Loading Data", "Mohon Tunggu...")
                    binding.loadingArtikel.root.visibility = View.VISIBLE
                    binding.emptyArtikel.root.visibility = View.GONE
                    binding.errorArtikel.root.visibility = View.GONE
                    binding.artikelList.visibility = View.GONE
                }

                is Resource.Success -> {
                    Log.d("Success", "Data berhasil diambil dari server")
                    binding.loadingArtikel.root.visibility = View.GONE
                    binding.emptyArtikel.root.visibility = View.GONE
                    binding.errorArtikel.root.visibility = View.GONE
                    binding.artikelList.visibility = View.VISIBLE
                    val menuItems = resource.data!!.items.mapIndexed { _, data ->
                        ArtikelTerkaitModel(
                            R.drawable.g_artikel_terkait1,
                            data.judul,
                            data.tanggal,
                            data.menit,
                            data.url
                        )
                    }
                    adapter.updateData(menuItems)
                }

                is Resource.Empty -> {
                    Log.d("Empty Data", "Data Tidak Ditemukan")
                    binding.loadingArtikel.root.visibility = View.GONE
                    binding.emptyArtikel.root.visibility = View.VISIBLE
                    binding.errorArtikel.root.visibility = View.GONE
                    binding.artikelList.visibility = View.GONE
                }

                is Resource.Error -> {
                    Log.d("Request Error", "Terjadi Kesalahan: {$resource.message}")
                    binding.loadingArtikel.root.visibility = View.GONE
                    binding.emptyArtikel.root.visibility = View.GONE
                    binding.errorArtikel.root.visibility = View.VISIBLE
                    binding.artikelList.visibility = View.GONE
                    binding.errorArtikel.errorMessage.text = resource.message
                    //listener tombol retry yang tampil jika terjadi error
                    binding.errorArtikel.retryButton.setOnClickListener {
                        artikelViewModel.getArtikels(requireContext(), true)
                    }
                }
            }
        }
    }

    private fun createArtikel() {
        val imageUrl = R.drawable.g_artikel_terkait1
        val judul = "Tips dan Trick Mengurangi Stress"
        val tanggal = "Jun 22, 2024"
        val menit = "10 min dilihat"
        val url = "https://prodia.co.id/id/artikel-detail/9-cara-mengatasi-stres-secara-efektif"

        val artikels = listOf(
            ArtikelRequest(imageUrl, judul, tanggal, menit, url)
        )
        artikelViewModel.createArtikel(requireContext(), artikels)
        artikelViewModel.createStatus.observe(viewLifecycleOwner) { resource ->
            when (resource) {
                is Resource.Loading -> {
                    Log.d("Loading Data", "Mengirim Data...")
                }

                is Resource.Success -> {
                    Log.d("Success", "Data berhasil diambil dari server")

                    Snackbar.make(
                        binding.root,
                        "Artikel created successfully!",
                        Snackbar.LENGTH_SHORT
                    ).show()
                }

                is Resource.Error -> {
                    Log.d("Request Error", "Terjadi Kesalahan: {$resource.message}")

                    Snackbar.make(
                        binding.root,
                        resource.message ?: "Failed to create artikel.",
                        Snackbar.LENGTH_LONG
                    ).show()
                }

                else -> {}
            }
        }
    }
}