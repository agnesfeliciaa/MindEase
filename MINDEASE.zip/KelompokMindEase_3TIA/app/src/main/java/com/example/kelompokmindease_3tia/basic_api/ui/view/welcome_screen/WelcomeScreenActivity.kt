package com.example.kelompokmindease_3tia.basic_api.ui.view.welcome_screen

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.viewpager2.widget.ViewPager2
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_api.ui.adapter.PageAdapter
import com.example.kelompokmindease_3tia.basic_api.ui.view.LoginActivity
import com.example.kelompokmindease_3tia.basic_api.ui.view.RegisterActivity
import com.tbuonomo.viewpagerdotsindicator.DotsIndicator

class WelcomeScreenActivity : AppCompatActivity() {


    private lateinit var viewPager:ViewPager2
    private lateinit var dotsIndicator:DotsIndicator
    private lateinit var btnSkip:Button
    private lateinit var btnNext:Button
    private lateinit var btnMulai:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_welcome_screen)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val textBelum : TextView = findViewById(R.id.txtBelum)

        viewPager=findViewById(R.id.ViewPager)


        val fragmentList= listOf(Welcome1Fragment(), Welcome2Fragment(), Welcome3Fragment())
        val adapter= PageAdapter(this, fragmentList)


        viewPager.adapter=adapter

        dotsIndicator=findViewById(R.id.dots_indicator)

        dotsIndicator.attachTo(viewPager)


        btnSkip=findViewById(R.id.btnSkip)
        btnSkip.setOnClickListener{
            finishWelcomeScreen()
        }

        btnNext=findViewById(R.id.btnNext)
        btnNext.setOnClickListener {
            if (viewPager.currentItem < fragmentList.size - 1) {
                viewPager.currentItem += 1
            } else {
                finishWelcomeScreen()
            }
        }

        val regisL : TextView = findViewById(R.id.regisL)
        regisL.setOnClickListener {
            val i= Intent(this, RegisterActivity::class.java)
            startActivity(i)
            finish()
        }

        btnMulai = findViewById(R.id.btnMulai)
        btnMulai.setOnClickListener {
            finishWelcomeScreen()
        }

        val imgBack : ImageView = findViewById(R.id.imageBack)
//        atur visible tombol back
        viewPager.registerOnPageChangeCallback(object: ViewPager2.OnPageChangeCallback(){
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                imgBack.visibility = if (position == 0) View.GONE else View.VISIBLE
                if (position == fragmentList.size - 1) {
                    btnNext.visibility = View.GONE
                    btnSkip.visibility = View.GONE
                    btnMulai.visibility = View.VISIBLE
                    regisL.visibility = View.VISIBLE
                    textBelum.visibility = View.VISIBLE
                } else{
                    btnNext.visibility = View.VISIBLE
                    btnSkip.visibility = View.VISIBLE
                    btnMulai.visibility = View.GONE
                    regisL.visibility = View.GONE
                    textBelum.visibility = View.GONE
                }
//                    btnSkip.visibility = View.GONE
//                } else {
//                    btnSkip.text = "Skip"
//                    btnSkip.visibility = View.GONE
//                }
            }
        })

        imgBack.setOnClickListener {
            viewPager.currentItem -= 1
        }

    }


    private fun finishWelcomeScreen(){
//        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    public fun replaceFragment(fragment: Fragment){
        val transaction=supportFragmentManager.beginTransaction()
        transaction.replace(R.id.ViewPager, fragment)
        //karena adanya perintah tersbut, agar kita membuat tumpukan stack untuk activity, jadi kebaca tiap tumpukan, jadi jika kita klik masing2 fragment jika back, maka akan back sesuai klik tadi, baru bisa ke home. jadi harus ada backtoStack, jadi ga langsung kill activity/finisih
        transaction.addToBackStack(null)
        transaction.commit()
    }
}
