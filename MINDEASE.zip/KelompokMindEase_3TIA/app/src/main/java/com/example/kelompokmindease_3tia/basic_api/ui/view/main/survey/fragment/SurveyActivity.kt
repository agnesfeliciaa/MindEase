package com.example.kelompokmindease_3tia.basic_api.ui.view.main.survey.fragment

import android.content.Intent
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.MainActivity

class SurveyActivity : AppCompatActivity() {

    private lateinit var frameLayout: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_survey)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val cancel: ImageView = findViewById(R.id.imageCancel)
        cancel.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }

        frameLayout = findViewById(R.id.fragment_container)

        // Tampilkan fragment pertama (Survey1Fragment)
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, Survey1Fragment())
            .commit()
    }

    fun replaceFragment(fragment: Fragment) {
        val currentFragment = supportFragmentManager.findFragmentById(R.id.fragment_container)
        if (currentFragment != null && currentFragment::class.java == fragment::class.java) {
            // Jika fragment saat ini sudah ditampilkan, hindari penggantian
            return
        }

        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.fragment_container, fragment)
        transaction.addToBackStack(null)
        transaction.commit()

        // Update judul berdasarkan fragment yang dipilih
        val textJudul: TextView = findViewById(R.id.textJudul)
        setFragmentTitle(fragment, textJudul)
    }

    private fun setFragmentTitle(fragment: Fragment, textJudul: TextView) {
        if (fragment is SurveyHasilHFragment || fragment is SurveyHasilKFragment || fragment is SurveyHasilMFragment) {
            textJudul.text = "Hasil Tes"
        }
    }

    fun clearBackStack() {
        val fragmentManager = supportFragmentManager
        while (fragmentManager.backStackEntryCount > 0) {
            fragmentManager.popBackStackImmediate()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        clearBackStack() // Bersihkan semua fragment saat aktivitas dihancurkan
    }
}


//package com.example.kelompokmindease_3tia.basic_api.ui.view.main.survey.fragment
//
//import android.content.Intent
//import android.os.Bundle
//import android.widget.FrameLayout
//import android.widget.ImageView
//import android.widget.TextView
//import androidx.activity.enableEdgeToEdge
//import androidx.appcompat.app.AppCompatActivity
//import androidx.core.view.ViewCompat
//import androidx.core.view.WindowInsetsCompat
//import androidx.fragment.app.Fragment
//import com.example.kelompokmindease_3tia.R
//import com.example.kelompokmindease_3tia.basic_api.ui.view.main.MainActivity
//import com.example.kelompokmindease_3tia.databinding.FragmentSurveyHasilHBinding
//import com.example.kelompokmindease_3tia.databinding.FragmentSurveyHasilKBinding
//import com.example.kelompokmindease_3tia.databinding.FragmentSurveyHasilMBinding
//
//class SurveyActivity : AppCompatActivity() {
//
//    private lateinit var frameLayout: FrameLayout
////    private lateinit var dotsIndicator:DotsIndicator
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        enableEdgeToEdge()
//        setContentView(R.layout.activity_survey)
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
//            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
//            insets
//        }
////        frameLayout=findViewById(R.id.fragment_container)
////
////
////        val fragmentList= listOf(Survey1Fragment(), Survey2Fragment(), Survey3Fragment(), Survey4Fragment(), Survey5Fragment(), Survey6Fragment(), Survey7Fragment(), Survey8Fragment(), Survey9Fragment(), Survey10Fragment())
////        val adapter= PageAdapter(this, fragmentList)
////
////
////        frameLayout.adapter=adapter
////
////        dotsIndicator=findViewById(R.id.dots_indicator)
////
////        dotsIndicator.attachTo(frameLayout)
//
//        val cancel: ImageView = findViewById(R.id.imageCancel)
//        cancel.setOnClickListener {
//            val i = Intent(this, MainActivity::class.java)
//            startActivity(i)
//            finish()
//        }
//
//        frameLayout = findViewById(R.id.fragment_container)
//
//        supportFragmentManager.beginTransaction().replace(R.id.fragment_container, Survey1Fragment()).commit()
//
//    }
//
//    public fun replaceFragment(fragment: Fragment) {
//        val transaction = supportFragmentManager.beginTransaction()
//        transaction.replace(R.id.fragment_container, fragment)
//        //karena adanya perintah tersbut, agar kita membuat tumpukan stack untuk activity, jadi kebaca tiap tumpukan, jadi jika kita klik masing2 fragment jika back, maka akan back sesuai klik tadi, baru bisa ke home. jadi harus ada backtoStack, jadi ga langsung kill activity/finisih
//        transaction.addToBackStack(null)
//        transaction.commit()
//
//        // Update judul berdasarkan fragment yang dipilih
//        val textJudul: TextView = findViewById(R.id.textJudul)
//        setFragmentTitle(fragment, textJudul)
//    }
//
//    private fun setFragmentTitle(fragment: Fragment, textJudul: TextView) {
//        // Mengatur judul yang sama untuk semua fragment hasil tes
//        if (fragment is SurveyHasilHFragment || fragment is SurveyHasilKFragment || fragment is SurveyHasilMFragment) {
//            textJudul.text = "Hasil Tes"
//        }
//    }
//
//}