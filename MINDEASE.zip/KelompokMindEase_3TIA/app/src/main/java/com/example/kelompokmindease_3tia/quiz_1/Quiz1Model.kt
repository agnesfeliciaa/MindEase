package com.example.kelompokmindease_3tia.quiz_1

class Quiz1Model (
    val name:String,
    val imageResid : Int
)