package com.example.kelompokmindease_3tia.basic_api.ui.adapter

import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.kelompokmindease_3tia.basic_api.ui.view.welcome_screen.WelcomeScreenActivity

class PageAdapter (
    activity: WelcomeScreenActivity,
    private val fragments: List<Fragment>
): FragmentStateAdapter(activity){


    override fun getItemCount():Int{
        return fragments.size
    }
    override fun createFragment(position:Int):Fragment{
        return fragments[position]
    }


}
