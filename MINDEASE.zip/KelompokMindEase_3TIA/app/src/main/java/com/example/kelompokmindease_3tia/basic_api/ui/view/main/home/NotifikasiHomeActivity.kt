package com.example.kelompokmindease_3tia.basic_api.ui.view.main.home

import android.os.Bundle
import android.widget.ImageView
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_api.data.model.NotifikasiHomeModel
import com.example.kelompokmindease_3tia.basic_api.ui.adapter.NotifikasiHomeAdapter

class NotifikasiHomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_notifikasi_home)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val listView:ListView=findViewById(R.id.listView)
        val menuList= listOf(
            NotifikasiHomeModel("Tetap Semangat", "Jangan stress berlebihan karena itu akan mengganggu pikiranmu", R.drawable.ic_circle_orange),
            NotifikasiHomeModel("Tarik nafas, keluarkan", "Luangkan waktu, tenangkan pikiran", R.drawable.ic_circle_blue),
            NotifikasiHomeModel("Surveii Check", "Jangan lupa untuk selalu recheck dan isi ulang survei setiap 1-2 minggu sekali ya!!", R.drawable.ic_circle_red),
        )

        //pemanggilan adapter context dll dari lst adapter
        val adapter= NotifikasiHomeAdapter(this,menuList)
        listView.adapter=adapter

        //
        listView.setOnItemClickListener{ parent, view, position, id ->
            val selectedItem= menuList[position]

            if(selectedItem.name=="Menu 5") {
                Toast.makeText(
                    this,
                    "Redirect ke halaman detail ${selectedItem.name}",
                    Toast.LENGTH_LONG
                ).show()
            }else {
                Toast.makeText(this, "Kamu klik ${selectedItem.name}", Toast.LENGTH_LONG).show()
            }
        }

        val imgBack: ImageView = findViewById(R.id.imageBack)
        imgBack.setOnClickListener {
            finish()
        }

    }
}