package com.example.kelompokmindease_3tia.basic_fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.example.kelompokmindease_3tia.R

class FragmentThird : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view= inflater.inflate(R.layout.fragment_basic_third, container, false)


        //mengambil data link
        val link=arguments?.getString("link")
        //println("apakah ada?" + link)


        val textFragment3 : TextView =view.findViewById(R.id.textFragment3)
        textFragment3.text=link
        return view
    }
}
