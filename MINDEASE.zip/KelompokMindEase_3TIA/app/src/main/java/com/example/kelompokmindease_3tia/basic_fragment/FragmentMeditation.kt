package com.example.kelompokmindease_3tia.basic_fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kelompokmindease_3tia.basic_recyclerview.ItemAdapter
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_recyclerview.ItemModel

class FragmentMeditation : Fragment() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ItemAdapter
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_meditation, container, false)

        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())// Menggunakan context dari fragment
        val items = listOf(
            ItemModel("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSIrYN4w-TJscbthBQi5IFOjNyvL0DcLkndSQ&s", "Diri yang lebih baik", "5 Menit"),
            ItemModel("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRZrjkEzWGt6CntX7rrgSM9wBjn3_U-h5Mi2g&s", "Stress dan Kecemasan", "4 menit"),
            ItemModel("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqCAABph_zt31ami0s0DnlAzeMZHWwY21bHw&s", "Tidur Lebih Nyeyak", "5 Menit"),
        )

//        adapter = ItemAdapter(items)
//        recyclerView.adapter
        adapter = ItemAdapter(items)
        recyclerView.adapter = adapter

        return view
    }
}