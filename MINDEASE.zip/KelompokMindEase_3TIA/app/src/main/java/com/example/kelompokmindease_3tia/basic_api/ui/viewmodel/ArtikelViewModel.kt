package com.example.kelompokmindease_3tia.basic_api.ui.viewmodel

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import com.example.kelompokmindease_3tia.basic_api.data.model.ArtikelRequest
import com.example.kelompokmindease_3tia.basic_api.data.model.ArtikelResponse
import com.example.kelompokmindease_3tia.basic_api.data.model.ArtikelTerkaitModel
import com.example.kelompokmindease_3tia.basic_api.data.repository.ArtikelRepository
import com.example.kelompokmindease_3tia.basic_api.utils.NetworkUtils
import com.example.kelompokmindease_3tia.basic_api.utils.Resource
import kotlinx.coroutines.launch

class ArtikelViewModel(private val repository: ArtikelRepository) : ViewModel() {
    //data di-set sebagai LiveData agar UI dapat melakukan observe status saat mengambildata
    private val _data = MutableLiveData<Resource<ArtikelResponse>>()
    val data: LiveData<Resource<ArtikelResponse>> = _data

    // createStatus di-set sebagai LiveData agar UI dapat melakukan observe status saat mengirim data
    private val _createStatus = MutableLiveData<Resource<Unit>>()
    val createStatus: LiveData<Resource<Unit>> = _createStatus

    fun getArtikels(context: Context, forceRefresh: Boolean = false) {
        if (_data.value == null || forceRefresh) {
            if (NetworkUtils.isNetworkAvailable(context)) {
                viewModelScope.launch {
                    try {
                        //delay(3000) aktifkan jika ingin melihat state Loading
                        _data.value = Resource.Loading()
                        val response = repository.fetchArtikel()
                        if (response.items.isEmpty()) {
                            _data.postValue(Resource.Empty("No users found"))
                        } else {
                            _data.postValue(Resource.Success(response))
                        }
                    } catch (e: Exception) {
                        _data.postValue(Resource.Error("Unknown error: ${e.message}"))
                    }
                }
            } else {
                _data.postValue(Resource.Error("No internet connection"))
            }
        }
    }

    fun createArtikel(context: Context, artikel: List<ArtikelRequest>) {
        if (NetworkUtils.isNetworkAvailable(context)) {
            viewModelScope.launch {
                try {
                    _createStatus.value = Resource.Loading()

                    val response = repository.createArtikel(artikel)
                    _createStatus.postValue(Resource.Success(Unit))

                    // Refresh data setelah create sukses
                    getArtikels(context, forceRefresh = true)

                }catch (e: Exception) {
                    _data.postValue(Resource.Error("Unknown error: ${e.message}"))
                }
            }
        } else {
            _createStatus.postValue(Resource.Error("No internet connection"))
        }
    }
}