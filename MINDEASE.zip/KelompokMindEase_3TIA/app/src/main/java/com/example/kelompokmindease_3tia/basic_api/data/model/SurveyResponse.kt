package com.example.kelompokmindease_3tia.basic_api.data.model

data class SurveyResponse(
    val prediction: Int // Prediksi hasil survey, bisa 0, 1, atau 2
)

