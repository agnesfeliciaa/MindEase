package com.example.kelompokmindease_3tia.basic_api.data.model

data class ArtikelResponse(
    val cursor: String,
    val items: List<ArtikelItems>,
    val next_page: String,
)

data class ArtikelItems(
    val _created: Double,
    val _data_type: String,
    val _is_deleted: Boolean,
    val _modified: Double,
    val _self_link: String,
    val _user: String,
    val _uuid: String,
    val imageUrl : Any,
    val judul : String,
    val tanggal : String,
    val menit : String,
    val url :String
)