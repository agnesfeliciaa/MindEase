package com.example.kelompokmindease_3tia.basic_api.data.model

data class ArtikelRequest (
    val imageUrl : Any,
    val judul : String,
    val tanggal : String,
    val menit : String,
    val url : String
)