package com.example.kelompokmindease_3tia.basic_api.ui.view.main.survey

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.databinding.FragmentSurveyBinding

class SurveyFragment : Fragment() {

    private var _binding : FragmentSurveyBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentSurveyBinding.inflate(inflater, container, false)

        binding.btnForm.setOnClickListener {
            val i = Intent(requireActivity(), MulaiSurveyActivity::class.java)
            startActivity(i)
        }

        return binding.root
    }

    private fun loadFragment(fragment: Fragment) {
        // Menggunakan childFragmentManager untuk fragment dalam fragment
        childFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }
}