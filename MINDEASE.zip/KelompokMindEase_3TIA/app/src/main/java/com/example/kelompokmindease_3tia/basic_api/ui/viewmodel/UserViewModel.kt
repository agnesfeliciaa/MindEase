package com.example.kelompokmindease_3tia.basic_api.ui.viewmodel

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kelompokmindease_3tia.basic_api.data.model.User
import com.example.kelompokmindease_3tia.basic_api.data.repository.UserRepository
import com.example.kelompokmindease_3tia.basic_api.utils.NetworkUtils
import com.example.kelompokmindease_3tia.basic_api.utils.Resource
import kotlinx.coroutines.launch


class UserViewModel(private val repository: UserRepository): ViewModel() {

    private val _data = MutableLiveData<Resource<List<User>>>()
    val data: LiveData<Resource<List<User>>> = _data

    fun getUsers(context: Context, forceRefresh: Boolean = false){
        if (_data.value == null || forceRefresh) {
            if (NetworkUtils.isNetworkAvailable(context)){
                viewModelScope.launch {
                    try {
                        //delay (3000)
                        _data.value = Resource.Loading()
                        val response = repository.fetchUsers()
                        if (response.isEmpty()){
                            _data.postValue((Resource.Empty("No users found")))
                        } else{
                            _data.postValue(Resource.Success(response))
                        }
                    } catch (e: Exception){
                        _data.postValue(Resource.Error("Unkwown error: ${e.message}"))
                    }
                }
            }
            else{
                _data.postValue(Resource.Error("No internet connection"))
            }
        }
    }
}
//class UserViewModel(private val repository: UserRepository): ViewModel() {
//    fun getUsers() = liveData(Dispatchers.IO){
//        try {
//            val response = repository.fetchUsers()
//            emit(response)
//        } catch (e: Exception){
//            emit(null)
//        }
//    }
//}
