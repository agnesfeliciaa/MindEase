package com.example.kelompokmindease_3tia


import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.kelompokmindease_3tia.basic_api.ui.view.LoginActivity


class FirstActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_first)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //Deklarasi/inisialisasi variabel
        val input1: EditText = findViewById(R.id.input1)
        val button1: Button = findViewById(R.id.button1)
        val result1: TextView = findViewById(R.id.result1)
        val input2: EditText = findViewById(R.id.input2)
        val button2: Button = findViewById(R.id.button2)
        val result2: TextView = findViewById(R.id.result2)
        val btnNext: Button= findViewById(R.id.btnNext)
        val welcome: TextView=findViewById(R.id.welcome)
        val btnLogout: Button = findViewById(R.id.btnLogout)


        val sharPref=getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        //inisialisasi username agar bisa memanggilan username yang diinputkan dari regis
        val username=intent.getStringExtra("username")
        welcome.setText("Welcome, " +username.toString() +"!" )

        button1.setOnClickListener {
            val x = input1.text.toString()
            val y = x.toInt() * x.toInt()
            result1.text = y.toString()
        }
        button2.setOnClickListener {
            val a = input2.text.toString()
            val b = result1.text.toString().toInt() * a.toInt()
            result2.text = b.toString()
        }
        //intent-->mengarahkan ke halaman selanjutnya dengan intent dan put extra untuk menampilkan valuenya
        btnNext.setOnClickListener {
            val i = Intent(this, SecondActivity::class.java)
            i.putExtra("name","Agnes Felicia")
            startActivity(i)
        }
        //Membuat logout
        btnLogout.setOnClickListener{
            val editor=sharPref.edit()
            editor.clear()
            editor.apply()
            val i = Intent(this, LoginActivity::class.java)
            //kta clear semua activity, incase bahwasannya akan dimulai dari awal seperti proses awal penggunaan aplikasi
            i.flags=Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(i)
            finish()
        }
    }
}
//
////inisialisasi username agar bisa memanggilan username yang diinputkan dari login
//        val username=intent.getStringExtra("inputUsername")
//        welcome.setText("Welcome, " +username.toString() +"!" )
//
//
//        button1.setOnClickListener {
//            val x = input1.text.toString()
//            val y = x.toInt() * x.toInt()
//            result1.text = y.toString()
//        }
//
//        button2.setOnClickListener {
//            val a = input2.text.toString()
//            val b = result1.text.toString().toInt() * a.toInt()
//            result2.text = b.toString()
//        }
//        //Intent-->Mengarahkan ke halaman selanjutnya dengan intent dan put extra untuk menampilkan valuenya
//        btnNext.setOnClickListener {
//            val i = Intent(this, SecondActivity::class.java)
//            i.putExtra("name","Agnes Felicia")
//            startActivity(i)
//        }

