package com.example.kelompokmindease_3tia.basic_api.ui.view.main.meditasi

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.databinding.FragmentMeditasiBinding

class MeditasiFragment : Fragment() {

    private var _binding : FragmentMeditasiBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentMeditasiBinding.inflate(inflater, container, false)

        loadFragment(MeditasiSemuaFragment())

        // Mengatur listener pada navbarToggleGroup
        binding.navbarToggleGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) { // Hanya diproses jika tombol benar-benar dipilih
                when (checkedId) {
                    binding.btnSemua.id -> {
                        loadFragment(MeditasiSemuaFragment())
                        updateButtonStyles(binding.btnSemua)
                    }
                    binding.btnPagi.id -> {
                        loadFragment(MeditasiPagiFragment())
                        updateButtonStyles(binding.btnPagi)
                    }
                    binding.btnTidur.id -> {
                        loadFragment(MeditasiTidurFragment())
                        updateButtonStyles(binding.btnTidur)
                    }
                    binding.btnFokus.id -> {
                        loadFragment(MeditasiFokusFragment())
                        updateButtonStyles(binding.btnFokus)
                    }
                }
            }
        }
//        setUpNewsHorizontal(binding)

        return binding.root
    }

//    private fun setUpNewsHorizontal(binding: FragmentMeditasiBinding){
////    private fun setUpNewsHorizontal(view:View){
////        val newsHorizontal:RecyclerView = view.findViewById(R.id.newsHorizontalList)
//        val items = listOf(
//            MeditasiModel(R.drawable.g_meditasi1, "Diri yang lebih baik", "6 Menit"),
//            MeditasiModel(R.drawable.g_meditasi2, "Stress dan Kecemasan", "6 Menit"),
//            MeditasiModel(R.drawable.g_meditasi3, "Tidur Lebih Nyeyak", "6 Menit"),
//        )
//
//        newsHorizontal.adapter = HomeNewsHorizontalAdapter(items)
//        newsHorizontal.layoutManager = LinearLayoutManager(this.context, LinearLayoutManager.HORIZONTAL, false)
//
//        binding.recyclerViewMeditasi.adapter = MeditasiAdapter(items)
//        binding.recyclerViewMeditasi.layoutManager = LinearLayoutManager(requireContext())
//    }

//    private fun loadFragment(fragment: Fragment){
//        val transaction = supportFragmentManager.beginTransaction()
//        transaction.replace(R.id.fragment_container, fragment)
//        transaction.commit()
//    }

    private fun loadFragment(fragment: Fragment) {
        // Menggunakan childFragmentManager untuk fragment dalam fragment
        childFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    /**
     * Fungsi untuk memperbarui gaya tombol yang dipilih
     */
    private fun updateButtonStyles(selectedButton: View) {
        // Reset gaya semua tombol
        resetButtonStyles()

        // Gaya tombol yang dipilih
        selectedButton.setBackgroundColor(resources.getColor(R.color.selectedBackgroundColor, null))
        (selectedButton as? com.google.android.material.button.MaterialButton)?.let {
            it.setTextColor(resources.getColor(R.color.selectedTextColor, null))
            it.strokeColor = resources.getColorStateList(R.color.selectedBorderColor, null)
        }
    }

    /**
     * Fungsi untuk mereset gaya semua tombol ke status tidak dipilih
     */
    private fun resetButtonStyles() {
        val buttons = listOf(
            binding.btnSemua,
            binding.btnPagi,
            binding.btnTidur,
            binding.btnFokus
        )

        buttons.forEach { button ->
            button.setBackgroundColor(resources.getColor(R.color.unselectedBackgroundColor, null))
            (button as? com.google.android.material.button.MaterialButton)?.let {
                it.setTextColor(resources.getColor(R.color.unselectedTextColor, null))
                it.strokeColor = resources.getColorStateList(R.color.unselectedBorderColor, null)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}