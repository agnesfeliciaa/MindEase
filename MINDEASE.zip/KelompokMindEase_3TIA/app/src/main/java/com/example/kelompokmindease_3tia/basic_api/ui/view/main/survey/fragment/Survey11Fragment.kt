package com.example.kelompokmindease_3tia.basic_api.ui.view.main.survey.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_api.ui.viewmodel.SurveyViewModel
import com.example.kelompokmindease_3tia.databinding.FragmentSurvey11Binding
import com.example.kelompokmindease_3tia.databinding.FragmentSurvey5Binding

class Survey11Fragment : Fragment() {

    private var _binding: FragmentSurvey11Binding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: SurveyViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSurvey11Binding.inflate(inflater, container, false)

        // Initialize ViewModel
        viewModel = ViewModelProvider(requireActivity()).get(SurveyViewModel::class.java)

        binding.buttonNext.setOnClickListener {
            val input1 = binding.studyLoad.text.toString()

            if (input1.isNotEmpty()) {
                val number = input1.toIntOrNull()
                if (number == null) {
                    Toast.makeText(requireContext(), "Masukkan angka yang valid", Toast.LENGTH_SHORT).show()
                } else if (number < 0 || number > 5) {
                    Toast.makeText(requireContext(), "Isi sesuai rentang (0-5)", Toast.LENGTH_SHORT).show()
                } else {
                    // Store input in the ViewModel
                    viewModel.setAnswer("study_load", number)

                    // Navigate to Survey12Fragment
                    (activity as? SurveyActivity)?.replaceFragment(Survey12Fragment())
                }
            } else {
                Toast.makeText(requireContext(), "Isi inputan", Toast.LENGTH_SHORT).show()
            }
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

//class Survey11Fragment : Fragment() {
//
//    private var _binding : FragmentSurvey11Binding? = null
//    private val binding get() = _binding!!
//
//    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View? {
//        _binding = FragmentSurvey11Binding.inflate(inflater, container, false)
//
//        binding.buttonNext.setOnClickListener {
//            val input1 = binding.studyLoad.text.toString()
//
//            if (input1.isNotEmpty()) {
//                val number = input1.toIntOrNull()
//                if (number == null) {
//                    Toast.makeText(requireContext(), "Masukkan angka yang valid", Toast.LENGTH_SHORT).show()
//                } else if (number < 0 || number > 5) {
//                    Toast.makeText(requireContext(), "Isi sesuai rentang (0-5)", Toast.LENGTH_SHORT).show()
//                } else {
//                    (activity as? SurveyActivity)?.replaceFragment(Survey12Fragment())
//                }
//            } else {
//                Toast.makeText(requireContext(), "Isi inputan", Toast.LENGTH_SHORT).show()
//            }
//        }
//
//        return binding.root
//    }
