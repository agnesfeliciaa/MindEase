package com.example.kelompokmindease_3tia.basic_api.data.model

class NotifikasiHomeModel (
    val name:String,
    val desc: String,
    val imageResid : Int
)