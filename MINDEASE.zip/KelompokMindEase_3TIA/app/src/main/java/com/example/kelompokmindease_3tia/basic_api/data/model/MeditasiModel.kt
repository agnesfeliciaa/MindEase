package com.example.kelompokmindease_3tia.basic_api.data.model

class MeditasiModel (
    val imageUrl: Any,
    val nama: String,
    val menit: String,
)
