package com.example.kelompokmindease_3tia.basic_api.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.kelompokmindease_3tia.basic_api.data.model.ArtikelTrendingModel
import com.example.kelompokmindease_3tia.databinding.ArtikelTrendingItemHorizontalBinding
import com.squareup.picasso.Picasso

class ArtikelTrendingAdapter (
    private var mList:List<ArtikelTrendingModel>,
    private val onItemClick: (String) -> Unit
): RecyclerView.Adapter<ArtikelTrendingAdapter.ViewHolder>(){

    fun updateData(newItems: List<ArtikelTrendingModel>){
        mList = newItems
        notifyDataSetChanged()
    }

    class ViewHolder(val binding: ArtikelTrendingItemHorizontalBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val  binding= ArtikelTrendingItemHorizontalBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = mList[position]

        // Cek tipe `imagaUrl` untuk menentukan cara memuat gambar
        if (item.imageUrl is String) {
            // Memuat URL eksternal dengan Picasso
            Picasso.get().load(item.imageUrl as String).into(holder.binding.imgTrending)
        } else if (item.imageUrl is Int) {
            // Memuat resource drawable lokal
            holder.binding.imgTrending.setImageResource(item.imageUrl as Int)
        }
        holder.binding.judulTrending.text = item.judul
        holder.binding.jenisTrending.text = item.jenis
        holder.binding.tanggalTrending.text = item.tanggal
        holder.binding.dilihatTrending.text = item.menit

        // Menangani klik pada item untuk membuka URL
        holder.binding.root.setOnClickListener {
            onItemClick(item.url)  // Mengirim URL ke callback untuk membuka WebView
        }
    }

    override fun getItemCount(): Int {
        return mList.size
    }
}