package com.example.kelompokmindease_3tia.basic_api.data.firebase

import android.util.Log
import com.example.kelompokmindease_3tia.basic_api.data.model.User
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class FirebaseAuthService {
    private val firebaseAuth = FirebaseAuth.getInstance()
    private val firestore = FirebaseFirestore.getInstance()

    suspend fun register(user: User): Boolean {
        return try {
            val authResult = firebaseAuth.createUserWithEmailAndPassword(user.email, user.password).await()
            authResult.user?.let {
                val userId = it.uid
                val userData = mapOf(
                    "id" to userId,
                    "name" to user.name,
                    "email" to user.email,
                    "phonenumber" to user.phonenumber
                )
                firestore.collection("users").document(userId).set(userData).await()
            }
            true
        } catch (e: Exception) {
            Log.e("FirebaseAuth", "Registration failed: ${e.message}")
            false
        }
    }


    suspend fun login(email: String, password: String): FirebaseUser? {
        return try {
            val authResult = firebaseAuth.signInWithEmailAndPassword(email, password).await()
            authResult.user
        } catch (e: Exception) {
            null
        }
    }

    fun getCurrentUser() = firebaseAuth.currentUser
    fun logout() = firebaseAuth.signOut()
}

//import com.google.firebase.auth.FirebaseAuth
//import com.google.firebase.auth.FirebaseUser
//import kotlinx.coroutines.tasks.await
//
//class FirebaseAuthService {
//    private val firebaseAuth = FirebaseAuth.getInstance()
//
//    suspend fun login(email: String, password: String): FirebaseUser? {
//        return try {
//            val authResult = FirebaseAuth.getInstance()
//                .signInWithEmailAndPassword(email, password)
//                .await()
//            authResult.user
//        } catch (e: Exception) {
//            null
//        }
//    }
//
//    suspend fun register(email: String, password: String): Boolean {
//        return try {
//            firebaseAuth.createUserWithEmailAndPassword(email, password).await()
//            true
//        } catch (e: Exception) {
//            false
//        }
//    }
//
//    fun getCurrentUser() = firebaseAuth.currentUser
//
//    fun logout() {
//        firebaseAuth.signOut()
//    }
//}