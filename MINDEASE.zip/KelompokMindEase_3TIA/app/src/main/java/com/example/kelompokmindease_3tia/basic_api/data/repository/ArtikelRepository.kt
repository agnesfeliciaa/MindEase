package com.example.kelompokmindease_3tia.basic_api.data.repository

import android.util.Log
import com.example.kelompokmindease_3tia.basic_api.data.model.ArtikelRequest
import com.example.kelompokmindease_3tia.basic_api.data.model.ArtikelResponse
import com.example.kelompokmindease_3tia.basic_api.data.model.ArtikelTerkaitModel
import com.example.kelompokmindease_3tia.basic_api.data.network.ApiService

class ArtikelRepository( private val api: ApiService) {
    private val tokenBearer = "Bearer mA_rauNqqFcTvB5rIHhxnBSFqv_3VTMuVM9cQxFGeU8C-3rY0g"

    suspend fun fetchArtikel(): ArtikelResponse {
        return api.getArtikels(tokenBearer)

    }

    suspend fun createArtikel(artikels: List<ArtikelRequest>): ArtikelResponse {
        return api.createArtikel(tokenBearer, artikels)
    }


}