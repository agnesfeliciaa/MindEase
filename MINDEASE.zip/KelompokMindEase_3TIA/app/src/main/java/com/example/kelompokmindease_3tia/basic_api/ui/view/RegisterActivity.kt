package com.example.kelompokmindease_3tia.basic_api.ui.view

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.kelompokmindease_3tia.R
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class RegisterActivity : AppCompatActivity() {

    private val firestore = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val sharPref : SharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val inputEmail: TextInputEditText = findViewById(R.id.inputEmailR)
        val inputUsername: TextInputEditText = findViewById(R.id.inputUsernameR)
        val inputPassword: TextInputEditText = findViewById(R.id.inputPasswordR)
        val inputPhone: TextInputEditText = findViewById(R.id.inputPhoneR)
        val inputConfirmPassword: TextInputEditText = findViewById(R.id.inputConfirmPassword)
        val btnRegister: Button = findViewById(R.id.btnRegister)
        val loginText: TextView = findViewById(R.id.LoginR)

        // Navigate to Login Activity
        loginText.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }

        // Register Button Click
        btnRegister.setOnClickListener {
            val email = inputEmail.text.toString().trim()
            val username = inputUsername.text.toString().trim()
            val phone = inputPhone.text.toString().trim()
            val password = inputPassword.text.toString().trim()
            val confirmPassword = inputConfirmPassword.text.toString().trim()

            if (email.isBlank() || username.isBlank() || phone.isBlank() || password.isBlank() || confirmPassword.isBlank()) {
                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (password != confirmPassword) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }


            registerUser(email, password, username, phone)


            // Pindah ke LoginActivity
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun registerUser(email: String, password: String, username: String, phone: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val userId = auth.currentUser?.uid
                    if (userId != null) {
                        saveUserDataToFirestore(userId, username, email, phone)
                    } else {
                        Log.e("RegisterActivity", "User ID is null after registration")
                        Toast.makeText(this, "Error: Could not retrieve user ID", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Log.e("RegisterActivity", "Error registering user: ${task.exception?.message}")
                    Toast.makeText(this, "Registration failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun saveUserDataToFirestore(userId: String, username: String, email: String, phone: String) {
        val userData = hashMapOf(
            "username" to username,
            "email" to email,
            "phone" to phone,
            "createdAt" to System.currentTimeMillis()
        )

        firestore.collection("users").document(userId).set(userData)
            .addOnSuccessListener {
                Log.d("Firestore", "User data added successfully")
                Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show()

//                // Simpan username ke SharedPreferences
//                val sharedPref = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
//                val editor = sharedPref.edit()
//                editor.putString("username", username)
//                editor.putString("email", email)
//                editor.apply()
            }
            .addOnFailureListener { e ->
                Log.e("Firestore", "Error adding user data: ${e.message}")
                Toast.makeText(this, "Failed to save user data: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}


//import android.content.Intent
//import android.os.Bundle
//import android.util.Log
//import android.widget.Button
//import android.widget.TextView
//import android.widget.Toast
//import androidx.activity.enableEdgeToEdge
//import androidx.appcompat.app.AppCompatActivity
//import androidx.core.view.ViewCompat
//import androidx.core.view.WindowInsetsCompat
//import com.example.kelompokmindease_3tia.R
//import com.example.kelompokmindease_3tia.basic_api.ui.view.main.MainActivity
//import com.google.android.material.textfield.TextInputEditText
//import com.google.firebase.auth.FirebaseAuth
//import com.google.firebase.firestore.FirebaseFirestore
//
//class RegisterActivity : AppCompatActivity() {
//
//    private val firestore = FirebaseFirestore.getInstance()
//    private val auth = FirebaseAuth.getInstance()
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        enableEdgeToEdge()
//        setContentView(R.layout.activity_register)
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
//            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
//            insets
//        }
//
//        val inputEmail: TextInputEditText = findViewById(R.id.inputEmailR)
//        val inputUsername: TextInputEditText = findViewById(R.id.inputUsernameR)
//        val inputPassword: TextInputEditText = findViewById(R.id.inputPasswordR)
//        val inputPhone: TextInputEditText = findViewById(R.id.inputPhoneR)
//        val inputConfirmPassword: TextInputEditText = findViewById(R.id.inputConfirmPassword)
//        val btnRegister: Button = findViewById(R.id.btnRegister)
//        val loginText: TextView = findViewById(R.id.LoginR)
//
//        // Navigate to Login Activity
//        loginText.setOnClickListener {
//            val intent = Intent(this, LoginActivity::class.java)
//            startActivity(intent)
//            finish()
//        }
//
//        // Register Button Click
//        btnRegister.setOnClickListener {
//            val email = inputEmail.text.toString().trim()
//            val username = inputUsername.text.toString().trim()
//            val phone = inputPhone.text.toString().trim()
//            val password = inputPassword.text.toString().trim()
//            val confirmPassword = inputConfirmPassword.text.toString().trim()
//
//            if (email.isBlank() || username.isBlank() || phone.isBlank() || password.isBlank() || confirmPassword.isBlank()) {
//                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show()
//                return@setOnClickListener
//            }
//            if (password != confirmPassword) {
//                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
//                return@setOnClickListener
//            }
//
//            registerUser(email, password, username, phone)
//        }
//    }
//
//    private fun registerUser(email: String, password: String, username: String, phone: String) {
//        auth.createUserWithEmailAndPassword(email, password)
//            .addOnCompleteListener { task ->
//                if (task.isSuccessful) {
//                    val userId = auth.currentUser?.uid
//                    if (userId != null) {
//                        saveUserDataToFirestore(userId, username, email, phone)
//                    } else {
//                        Log.e("RegisterActivity", "User ID is null after registration")
//                        Toast.makeText(this, "Error: Could not retrieve user ID", Toast.LENGTH_SHORT).show()
//                    }
//                } else {
//                    Log.e("RegisterActivity", "Error registering user: ${task.exception?.message}")
//                    Toast.makeText(this, "Registration failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
//                }
//            }
//    }
//
//    private fun saveUserDataToFirestore(userId: String, username: String, email: String, phone: String) {
//        val userData = hashMapOf(
//            "username" to username,
//            "email" to email,
//            "phone" to phone,
//            "createdAt" to System.currentTimeMillis()
//        )
//
//        firestore.collection("users").document(userId).set(userData)
//            .addOnSuccessListener {
//                Log.d("Firestore", "User data added successfully")
//                Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show()
//                navigateToMainScreen()
//            }
//            .addOnFailureListener { e ->
//                Log.e("Firestore", "Error adding user data: ${e.message}")
//                Toast.makeText(this, "Failed to save user data: ${e.message}", Toast.LENGTH_SHORT).show()
//            }
//    }
//
//    private fun navigateToMainScreen() {
//        val intent = Intent(this, LoginActivity::class.java)
//        startActivity(intent)
//        finish()
//    }
//}


//package com.example.kelompokmindease_3tia.basic_api.ui.view
//
//import android.content.Intent
//import android.os.Bundle
//import android.util.Log
//import android.widget.Button
//import android.widget.TextView
//import android.widget.Toast
//import androidx.activity.enableEdgeToEdge
//import androidx.activity.viewModels
//import androidx.appcompat.app.AppCompatActivity
//import androidx.core.view.ViewCompat
//import androidx.core.view.WindowInsetsCompat
//import com.example.kelompokmindease_3tia.R
//import com.example.kelompokmindease_3tia.basic_api.data.firebase.FirebaseAuthService
//import com.example.kelompokmindease_3tia.basic_api.data.model.User
//import com.example.kelompokmindease_3tia.basic_api.data.repository.FirebaseRepository
//import com.example.kelompokmindease_3tia.basic_api.ui.viewmodel.FirebaseViewModel
//import com.example.kelompokmindease_3tia.basic_api.utils.Resource
//import com.example.kelompokmindease_3tia.basic_api.utils.ViewModelFactory
//import com.google.android.material.textfield.TextInputEditText
//import com.google.firebase.auth.FirebaseAuth
//import com.google.firebase.firestore.FirebaseFirestore
//
//class RegisterActivity : AppCompatActivity() {
//    private val firebaseViewModel: FirebaseViewModel by viewModels()
//
//
//    val firestore = FirebaseFirestore.getInstance()
//
////    private val firebaseViewModel: FirebaseViewModel by viewModels {
////        ViewModelFactory(FirebaseViewModel::class.java) {
////            val repository = FirebaseRepository(FirebaseAuthService())
////            FirebaseViewModel(repository)
////        }
////    }
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        enableEdgeToEdge()
//        setContentView(R.layout.activity_register)
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
//            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
//            insets
//        }
//
//
//        val inputEmail: TextInputEditText = findViewById(R.id.inputEmailR)
//        val inputUsernameR: TextInputEditText = findViewById(R.id.inputUsernameR)
//        val inputPassword: TextInputEditText = findViewById(R.id.inputPasswordR)
//        val inputPhoneR: TextInputEditText = findViewById(R.id.inputPhoneR)
//        val inputConfirmPassword: TextInputEditText = findViewById(R.id.inputConfirmPassword)
//        val btnRegister: Button = findViewById(R.id.btnRegister)
//        val LoginR: TextView = findViewById(R.id.LoginR)
//
//        //click textView Login pada regis (sudah punya akun?) untuk ke halaman Login
//        LoginR.setOnClickListener {
//            val i = Intent(this, LoginActivity::class.java)
//            // startActivity(i)
//            finish()
//        }
//
//        btnRegister.setOnClickListener {
//            val email = inputEmail.text.toString()
//            val password = inputPassword.text.toString()
//            val confirmPassword = inputConfirmPassword.text.toString()
//
//            if (email.isBlank() || password.isBlank() || confirmPassword.isBlank()) {
//                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show()
//                return@setOnClickListener
//            }
//            if (password != confirmPassword) {
//                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
//                return@setOnClickListener
//            }
//
//            firebaseViewModel.register(User(null, "", email, password, password, ""))
//        }
//        val userId = FirebaseAuth.getInstance().currentUser?.uid
//        if (userId == null) {
//            Log.e("Firestore", "Error: userId is null")
//            return
//        }
//
//        val userData = hashMapOf(
//            "name" to "User Name",
//            "email" to "user@example.com"
//        )
//
//        firestore.collection("users").document(userId).set(userData)
//            .addOnSuccessListener {
//                Log.d("Firestore", "User data added successfully")
//            }
//            .addOnFailureListener { e ->
//                Log.e("Firestore", "Error adding user data: ${e.message}")
//            }

//class RegisterActivity : AppCompatActivity() {
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        enableEdgeToEdge()
//        setContentView(R.layout.activity_register)
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
//            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
//            insets
//        }
//        val sharPref : SharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
//        val inputEmailR: TextInputEditText = findViewById(R.id.inputEmailR)
//        val inputUsernameR: TextInputEditText = findViewById(R.id.inputUsernameR)
//        val inputPasswordR: TextInputEditText = findViewById(R.id.inputPasswordR)
//        val inputConfirmPassword: TextInputEditText = findViewById(R.id.inputConfirmPassword)
//        val LoginR: TextView = findViewById(R.id.LoginR)
//        val btnRegister: Button =findViewById(R.id.btnRegister)
//
//        //click textView Login pada regis (sudah punya akun?) untuk ke halaman Login
//        LoginR.setOnClickListener{
//            val i = Intent(this, LoginActivity::class.java)
//           // startActivity(i)
//            finish()
//        }
//
//        //kondisi/ketentuan sebelum klik button Register
//        btnRegister.setOnClickListener {
//            val e = inputEmailR.text.toString()
//            val p = inputPasswordR.text.toString()
//            val cp= inputConfirmPassword.text.toString()
//            val a = inputUsernameR.text.toString()
//            //kondisi dari kemungkinan yang terjadi
//            if (e.isEmpty() || p.isEmpty() || cp.isEmpty() || a.isEmpty()) {
//                Toast.makeText(this, "Inputan tidak boleh kosong", Toast.LENGTH_SHORT).show()
//                return@setOnClickListener
//            } else{
//                if (p == cp ) {
//                    btnRegister.setBackgroundColor(Color.parseColor("#4A90E2"))
//                    //set username ke shared preferences
//                    val editor=sharPref.edit()
//                    editor.putString("email", e)
//                    editor.putString("username", a)
//                    editor.putString("password", p)
//                    editor.putString("confirm password", cp)
//                    editor.apply()
//                    finish()
////                //Pemanggilan intent untuk berpindah ke LoginAct
////                val i = Intent(this, LoginActivity::class.java)
////                //meletakkan nama  ID inputUsername yaitu a agar saat main activity bisa diambil data inputannya
////                i.putExtra("username", a)
////                startActivity(i)
//                } else {
//                    //penggunaan snackbar untuk pop up
//                    val view = this.findViewById<View>(android.R.id.content)
//                    val snackbar = Snackbar.make(view, "Password dan confirm password belum sama", Snackbar.LENGTH_LONG)
//                    snackbar.show()
//                }
//            }
//        }
//    }
//}
////                val toast= Toast.makeText(this, "password dan confirm password belum sama", Toast.LENGTH_LONG)
////                toast.show()
