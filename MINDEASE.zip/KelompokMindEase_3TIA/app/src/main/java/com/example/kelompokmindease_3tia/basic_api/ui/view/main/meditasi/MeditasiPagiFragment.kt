package com.example.kelompokmindease_3tia.basic_api.ui.view.main.meditasi

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_api.data.model.MeditasiModel
import com.example.kelompokmindease_3tia.databinding.FragmentMeditasiPagiBinding
import com.example.kelompokmindease_3tia.basic_api.ui.adapter.MeditasiAdapter

class MeditasiPagiFragment : Fragment() {

    private var _binding : FragmentMeditasiPagiBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentMeditasiPagiBinding.inflate(inflater, container, false)

        setUpNewsHorizontal(binding)

        return binding.root
    }

    private fun setUpNewsHorizontal(binding: FragmentMeditasiPagiBinding){
//    private fun setUpNewsHorizontal(view:View){
//        val newsHorizontal:RecyclerView = view.findViewById(R.id.newsHorizontalList)
        val items = listOf(
            MeditasiModel(R.drawable.g_meditasi1, "Diri yang lebih baik", "5 Menit"),
        )

        binding.recyclerViewMeditasi.adapter = MeditasiAdapter(items)
        binding.recyclerViewMeditasi.layoutManager = LinearLayoutManager(requireContext())
    }
}