package com.example.kelompokmindease_3tia.basic_api.ui.view.main.survey.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.artikel.ArtikelFragment
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.artikel.ArtikelSemuaFragment
import com.example.kelompokmindease_3tia.databinding.FragmentSurvey13Binding
import com.example.kelompokmindease_3tia.databinding.FragmentSurveyHasilHBinding

class SurveyHasilHFragment : Fragment() {

    private var _binding : FragmentSurveyHasilHBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentSurveyHasilHBinding.inflate(inflater, container, false)

        binding.button1.setOnClickListener {
            val fragment = ArtikelSemuaFragment() // Buat instance fragment tujuan
            activity?.supportFragmentManager?.beginTransaction()?.apply {
                replace(R.id.fragment_container, fragment) // Ganti R.id.fragment_container dengan ID container Anda
                addToBackStack(null) // Tambahkan ke backstack jika ingin memungkinkan navigasi kembali
                commit()
            }
        }


        binding.button2.setOnClickListener{
            activity?.finish()
        }

        return binding.root
    }
}