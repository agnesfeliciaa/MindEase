package com.example.kelompokmindease_3tia.basic_api.data.network

import com.example.kelompokmindease_3tia.basic_api.data.model.SurveyResponse
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

object ApiClient {
    // Pastikan hanya domain dan port, tanpa /predict
    private const val BASE_URL = "http://172.20.10.4:5000/"
    val instance: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }

    interface ApiService {
        @POST("predict") // Endpoint ditambahkan di sini
        fun submitSurvey(@Body answers: Map<String, Int>): Call<SurveyResponse>
    }
}
