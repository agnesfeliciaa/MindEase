package com.example.kelompokmindease_3tia.quiz_1

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.example.kelompokmindease_3tia.R

class Quiz1Adapter (
    context: Context,
    private  val quiz1List:List<Quiz1Model>
) : ArrayAdapter<Quiz1Model>(context, 0, quiz1List) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.quiz1_item,parent, false)

        val menuItem = getItem(position)
        val imageView : ImageView = view.findViewById(R.id.imageView)
        val textName : TextView = view.findViewById(R.id.textName)

        menuItem?.let{
            imageView.setImageResource(it.imageResid)
            textName.text = it.name
        }

        return view
    }
}