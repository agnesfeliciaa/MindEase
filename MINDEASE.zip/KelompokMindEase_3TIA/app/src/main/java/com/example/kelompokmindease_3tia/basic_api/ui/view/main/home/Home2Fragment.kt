package com.example.kelompokmindease_3tia.basic_api.ui.view.main.home

import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_api.data.model.HomeNewsHorizontalModel
import com.example.kelompokmindease_3tia.basic_api.data.network.RetrofitInstance
import com.example.kelompokmindease_3tia.basic_api.data.repository.UserRepository
import com.example.kelompokmindease_3tia.basic_api.ui.adapter.AutoSliderAdapter
import com.example.kelompokmindease_3tia.basic_api.ui.adapter.HomeNewsHorizontalAdapter
import com.example.kelompokmindease_3tia.basic_api.ui.view.LoginActivity
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.survey.MulaiSurveyActivity
import com.example.kelompokmindease_3tia.basic_api.ui.viewmodel.UserViewModel
import com.example.kelompokmindease_3tia.basic_api.utils.Resource
import com.example.kelompokmindease_3tia.basic_api.utils.ViewModelFactory
import com.example.kelompokmindease_3tia.databinding.ActivityHomeRekomendasiWebViewBinding
import com.example.kelompokmindease_3tia.databinding.FragmentHome2Binding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class Home2Fragment : Fragment() {
    private var _binding: FragmentHome2Binding? = null
    private val binding get() = _binding!!
    private val firestore = FirebaseFirestore.getInstance()

//    private val userViewModel: UserViewModel by lazy {
//        val repository = UserRepository(RetrofitInstance.getJsonPlaceholderApi())
//        ViewModelProvider(
//            this,
//            ViewModelFactory(UserViewModel::class.java) { UserViewModel(repository) })[UserViewModel::class.java]
//    }

    private val userViewModel: UserViewModel by activityViewModels {
        ViewModelFactory(UserViewModel::class.java) {
            val repository = UserRepository(RetrofitInstance.getJsonPlaceholderApi())
            UserViewModel(repository)
        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentHome2Binding.inflate(inflater, container, false)

//        // Inflate the layout for this fragment
//        val view = inflater.inflate(R.layout.fragment_home2, container, false)

//        setupAutoSlide(view)
//        setupGripMenu(view)
//        setUpNewsHorizontal(view)

        setupAutoSlide(binding)
        setupGripMenu(binding)
        setUpNewsHorizontal(binding)

        val sharPref = requireActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val username = sharPref.getString("username", null) // Ambil username dari SharedPreferences
        binding.textHai.text = "\uD83D\uDC4B Hai, $username!"

        binding.imageNotif.setOnClickListener {
            val i = Intent(requireActivity(), NotifikasiHomeActivity::class.java)
            startActivity(i)
        }

        binding.btnMulai.setOnClickListener {
            val i = Intent(requireActivity(), MulaiSurveyActivity::class.java)
            startActivity(i)
        }
//
//        return view
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Ambil data username dari Firestore
        fetchUsernameFromFirestore()
    }

    //    private fun setupAutoSlide(view: View){
    private fun setupAutoSlide(binding: FragmentHome2Binding) {
        val imagesUrl = listOf(
//            "https://www.blibli.com/friends-backend/wp-content/uploads/2023/09/B900245-Cover-Cara-Membuat-Podcast-di-Spotify-scaled.jpg",
//            "https://blog.sribu.com/wp-content/uploads/2023/08/pasted-image-0-3.png",
//            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTIAlnlI6NviqSKbm8ikARfx8aP2zdQYLF7Nw&s",
            R.drawable.g_podcast1,
            R.drawable.g_podcast2,
            R.drawable.g_podcast3,
        )

//        val viewPager:ViewPager2=view.findViewById(R.id.autoSlider)
//        val dotsIndicator:WormDotsIndicator=view.findViewById(R.id.dots_indicator)
//        viewPager.adapter=AutoSliderAdapter(imagesUrl,viewPager)
//        dotsIndicator.attachTo(viewPager)
        val urls = listOf(
            "https://youtu.be/9QnsB9SCzjw?si=VTGEt1cy0L8LTCYF",
            "https://youtu.be/S7sv5U38c_0?si=BwS-iGh6DzwXX92U",
            "https://youtu.be/zcTJZzFT6hs?si=cdHFFUcH8dep66WT"
        )

        // Setup adapter
        binding.autoSlider.adapter = AutoSliderAdapter(imagesUrl, binding.autoSlider) { position ->
            val url = urls[position]
            saveUrlToPreferences(url)
            openWebViewActivity(url)
        }
        binding.dotsIndicator.attachTo(binding.autoSlider)
    }

    private fun saveUrlToPreferences(url: String) {
        requireContext().getSharedPreferences("MyPrefs", MODE_PRIVATE).edit()
            .putString("last_clicked_url", url).apply()
    }

    private fun openWebViewActivity(url: String) {
        val intent = Intent(requireContext(), HomePodcastWebViewActivity::class.java)
        intent.putExtra("url", url)  // Mengirim URL ke WebViewActivity
        startActivity(intent)
    }

    //    private fun setupGripMenu(view: View){
    private fun setupGripMenu(binding: FragmentHome2Binding) {
//        val cardMenu1 : CardView = view.findViewById(R.id.cardMenu1)
//        val cardMenu2 : CardView = view.findViewById(R.id.cardMenu2)
//        val cardMenu3 : CardView = view.findViewById(R.id.cardMenu3)
//        val cardMenu4 : CardView = view.findViewById(R.id.cardMenu4)
//        val cardMenu5 : CardView = view.findViewById(R.id.cardMenu5)

        binding.includeHomeMenuGrid.cardMenu1.setOnClickListener {
            Toast.makeText(context, "Aku sangat sedih, gimana? \uD83D\uDE22", Toast.LENGTH_SHORT)
                .show()
        }
        binding.includeHomeMenuGrid.cardMenu2.setOnClickListener {
            Toast.makeText(context, "Aku sedih \uD83D\uDE1E", Toast.LENGTH_SHORT).show()
        }
        binding.includeHomeMenuGrid.cardMenu3.setOnClickListener {
            Toast.makeText(context, "Biasa aja \uD83D\uDE10", Toast.LENGTH_SHORT).show()
        }
        binding.includeHomeMenuGrid.cardMenu4.setOnClickListener {
            Toast.makeText(context, "Aku senang \uD83D\uDE42", Toast.LENGTH_SHORT).show()
        }
        binding.includeHomeMenuGrid.cardMenu5.setOnClickListener {
            Toast.makeText(context, "Aku sangat senang \uD83D\uDE04", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setUpNewsHorizontal(binding: FragmentHome2Binding) {
        val items = listOf(
            HomeNewsHorizontalModel(
                "Tips and Trick",
                R.drawable.g_tipsdantrik,
                "Kurangi stress berlebihan",
                "#FFBB56",
                "#F4A630",
                "https://www.alodokter.com/ternyata-tidak-sulit-mengatasi-stres"
            ),
            HomeNewsHorizontalModel(
                "Beli Paket Konsultasi Lebih Hemat !",
                R.drawable.g_lebih_hemat,
                "Diskon 50% untuk paket 6 sesi 60 menit",
                "#717EEE",
                "#5D69CF",
                "https://prodia.co.id/id/test-detail-genomik/TH2pxO2hp2I=-th2pxo2hp2i=-prodia-sleep--stress-genomics-add-on"
            )
        )

        // Menetapkan adapter dan menambahkan callback onClick
        binding.newsHorizontalList.adapter = HomeNewsHorizontalAdapter(items) { url ->
            // Ketika item diklik, buka WebView dengan URL yang diteruskan
            openWebViewActivity1(url)
        }
        binding.newsHorizontalList.layoutManager =
            LinearLayoutManager(this.context, LinearLayoutManager.HORIZONTAL, false)
    }

    private fun openWebViewActivity1(url: String) {
        val intent = Intent(requireContext(), HomeRekomendasiWebViewActivity::class.java)
        intent.putExtra("url", url)  // Mengirim URL ke WebViewActivity
        startActivity(intent)
    }
    private fun fetchUsernameFromFirestore() {
        val currentUser = FirebaseAuth.getInstance().currentUser

        if (currentUser != null) {
            val userId = currentUser.uid

            // Ambil data username dari Firestore
            firestore.collection("users").document(userId).get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val username = document.getString("username") ?: "Pengguna"
                        binding.textHai.text = "\uD83D\uDC4B Hai, $username!"
                    } else {
                        binding.textHai.text = "\uD83D\uDC4B Hai, Pengguna!"
                    }
                }
                .addOnFailureListener {
                    binding.textHai.text = "\uD83D\uDC4B Hai, Pengguna!"
                }
        } else {
            // Jika user belum login, arahkan ke LoginActivity
            val intent = Intent(requireActivity(), LoginActivity::class.java)
            startActivity(intent)
            requireActivity().finish()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }



//    private fun ApiNewsHorizontal(binding: FragmentHome2Binding){
//        val adapter = HomeNewsHorizontalAdapter(emptyList())
//        userViewModel.getUsers().observe(requireActivity()) { resp ->
//            if (resp != null) {
//                val items = resp.mapIndexed { index, data ->
//                    HomeNewsHorizontalModel(
//                        data.name,
//                        "https://blog.sribu.com/wp-content/uploads/2023/08/pasted-image-0-3.png", "Kurangi stress berlebihan", "#FFBB56", "#F4A630")
//                }
//                adapter.updateData(items)
//            } else {
//                //
//            }
//        }
//        binding.newsHorizontalList.adapter = adapter
//        binding.newsHorizontalList.layoutManager =
//            LinearLayoutManager(this.context, LinearLayoutManager.HORIZONTAL, false)
//    }

//    private fun ApiNewsHorizontal(binding: FragmentHome2Binding) {
//        val adapter = HomeNewsHorizontalAdapter(emptyList())
//        //        userViewModel.getUsers().observe(viewLifecycleOwner) { response ->
//        //            response?.articles?.let { articles ->  // Akses articles dari NewsResponse
//        //                val items = articles.mapIndexed { index, article ->
//        //                    HomeNewsHorizontalModel(
//        //                        title = article.author,
//        //                        isi = article.title,
//        //                        imagaUrl = article.urlToImage,
//        //                        background = "#FFBB56",
//        //                        backgroundIsi = "#F4A630",
//        //                    )
//        //                }
//        //                adapter.updateData(items)
//        //            }
//        //        }
//
//        // Kode untuk mendapatkan data User
//        userViewModel.getUsers(requireContext())
//
//        // Kode untuk melakukan pengamatan (observe) perubahan pada variable "data",
//        // dimana "data" sudah didefinisikan sebagai LiveData pada ViewModel
//        userViewModel.data.observe(viewLifecycleOwner) { resource ->
//            when (resource) {
//                is Resource.Loading -> {
//                    Log.d("GET Data User", "Mohon Tunggu...")
//                    binding.loadingNewsVertical.root.visibility = View.VISIBLE
//                    binding.emptyNewsVertical.root.visibility = View.GONE
//                    binding.errorNewsVertical.root.visibility = View.GONE
//                    binding.newsHorizontalList.visibility = View.GONE
//                }
//
//                is Resource.Success -> {
//                    Log.d("GET Data User", "Data berhasil didapatkan!")
//
//                    binding.loadingNewsVertical.root.visibility = View.GONE
//                    binding.emptyNewsVertical.root.visibility = View.GONE
//                    binding.errorNewsVertical.root.visibility = View.GONE
//                    binding.newsHorizontalList.visibility = View.VISIBLE
//
//                    val items = resource.data!!.mapIndexed { index, data ->
//                        HomeNewsHorizontalModel(
//                            data.name,
//                            "https://blog.sribu.com/wp-content/uploads/2023/08/pasted-image-0-3.png",
//                            data.name,
//                            "#ffffff",
//                            "#000000",
//                            "https://www.alodokter.com/ternyata-tidak-sulit-mengatasi-stres"
//                        )
//                    }
//                    adapter.updateData(items)
//                }
//
//                is Resource.Empty -> {
//                    Log.d("GET Data User", resource.message.toString())
//
//                    binding.loadingNewsVertical.root.visibility = View.GONE
//                    binding.emptyNewsVertical.root.visibility = View.VISIBLE
//                    binding.errorNewsVertical.root.visibility = View.GONE
//                    binding.newsHorizontalList.visibility = View.GONE
//                }
//
//                is Resource.Error -> {
//                    Log.e("GET Data User", resource.message.toString())
//
//                    binding.loadingNewsVertical.root.visibility = View.GONE
//                    binding.emptyNewsVertical.root.visibility = View.GONE
//                    binding.errorNewsVertical.root.visibility = View.VISIBLE
//                    binding.newsHorizontalList.visibility = View.GONE
//                }
//            }
//        }
//
//        binding.newsHorizontalList.adapter = adapter
//        binding.newsHorizontalList.layoutManager =
//            LinearLayoutManager(this.context, LinearLayoutManager.HORIZONTAL, false)
//    }
//        ApiNewsHorizontal(binding)


//        val welcome: TextView = view.findViewById(R.id.textHai)
//        val sharPref = requireActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
//        val username = sharPref.getString("username", null) // Ambil username dari SharedPreferences
//        welcome.text = "\uD83D\uDC4B Hai, $username!"
//
//        val notif: ImageView = view.findViewById(R.id.imageNotif)
//        notif.setOnClickListener {
//            val i = Intent(requireActivity(), ListViewActivity::class.java)
//            startActivity(i)
//        }
//
//        val btnMulai: Button = view.findViewById(R.id.btnMulai)
//        btnMulai.setOnClickListener {
//            val i = Intent(requireActivity(), SurveyActivity::class.java)
//            startActivity(i)
//        }


//    private fun ApiNewsHorizontal(binding: FragmentHome2Binding){
//        val adapter = HomeNewsHorizontalAdapter(emptyList())
//        userViewModel.getUsers().observe(requireActivity()) { resp ->
//            if (resp != null) {
//                val items = resp.mapIndexed { index, data ->
//                    HomeNewsHorizontalModel(
//                        data.name,
//                        "https://blog.sribu.com/wp-content/uploads/2023/08/pasted-image-0-3.png", "Kurangi stress berlebihan", "#FFBB56", "#F4A630")
//                }
//                adapter.updateData(items)
//            } else {
//                //
//            }
//        }
//        binding.newsHorizontalList.adapter = adapter
//        binding.newsHorizontalList.layoutManager =
//            LinearLayoutManager(this.context, LinearLayoutManager.HORIZONTAL, false)
//    }
}