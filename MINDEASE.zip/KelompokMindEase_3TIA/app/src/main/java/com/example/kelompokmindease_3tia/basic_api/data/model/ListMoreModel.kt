package com.example.kelompokmindease_3tia.basic_api.data.model

class ListMoreModel (
    val name:String,
    val desc: String,
)