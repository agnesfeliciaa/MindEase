package com.example.kelompokmindease_3tia.basic_api.ui.view.main.survey

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.WebViewActivity
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.survey.fragment.SurveyActivity

class MulaiSurveyActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_mulai_survey)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val cancel: ImageView = findViewById(R.id.imageCancel)
        cancel.setOnClickListener {
            val i = Intent(this, com.example.kelompokmindease_3tia.basic_api.ui.view.main.MainActivity::class.java)
            startActivity(i)
        }

        val btnMulai:Button = findViewById(R.id.buttonMulai)
        btnMulai.setOnClickListener{
            val j = Intent(this, com.example.kelompokmindease_3tia.basic_api.ui.view.main.MainActivity::class.java)
            startActivity(j)
            val i = Intent(this, SurveyActivity::class.java)
            startActivity(i)
            finish()
        }
    }
}