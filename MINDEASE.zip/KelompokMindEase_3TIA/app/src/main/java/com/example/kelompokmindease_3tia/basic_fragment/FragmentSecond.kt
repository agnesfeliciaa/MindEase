package com.example.kelompokmindease_3tia.basic_fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import com.example.kelompokmindease_3tia.R

class FragmentSecond : Fragment() {


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_basic_second, container, false)


        val btnGoToFragmentThird : Button =view.findViewById(R.id.btnGoToFragmentThird)


        //berpindah untuk simpan data
        btnGoToFragmentThird.setOnClickListener {
            val fragmentThird=FragmentThird()


            val  bundle=Bundle()
            bundle.putString("link", "https://www.halodoc.com/kesehatan/kesehatan-mental?srsltid=AfmBOorkbLRx59fGPVPRf6zv_gScL7MNqfiisvSySvOkZ6-0EOFYcjg6")
            fragmentThird.arguments=bundle


            //pada replaceFragment(fragmentThird) -->dimana fragmentThird ambil dari variabel val fragmentThirdnya.
            (activity as? FragmentActivity)?.replaceFragment(fragmentThird)
        }
        return view
    }
}
