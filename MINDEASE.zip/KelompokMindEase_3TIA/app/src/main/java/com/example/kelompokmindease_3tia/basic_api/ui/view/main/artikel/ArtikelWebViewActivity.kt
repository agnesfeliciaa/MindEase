package com.example.kelompokmindease_3tia.basic_api.ui.view.main.artikel

import android.os.Bundle
import android.view.MenuItem
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.kelompokmindease_3tia.R

class ArtikelWebViewActivity : AppCompatActivity() {
    //inisialisasikan lateinit dlu
    private lateinit var webView: WebView
    private lateinit var toolbar: Toolbar



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_artikel_web_view)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        //inisialisasi toolbar
        toolbar=findViewById(R.id.toolbar)
        toolbar.setTitle("Artikel")
        setSupportActionBar(toolbar)

        //inisialisasi tombol back
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)

        //inisialisasi web view
        webView=findViewById(R.id.webView)
        webView.settings.javaScriptEnabled=true
        //webView.loadUrl("https://www.halodoc.com/kesehatan/kesehatan-mental?srsltid=AfmBOorkbLRx59fGPVPRf6zv_gScL7MNqfiisvSySvOkZ6-0EOFYcjg6")
        // Ambil URL dari Intent
        val url = intent.getStringExtra("url")
        if (url != null && url.isNotEmpty()) {
            webView.loadUrl(url)
        } else {
            Toast.makeText(this, "URL tidak ditemukan atau tidak valid", Toast.LENGTH_SHORT).show()
            finish() // Kembali ke layar sebelumnya jika URL tidak valid
        }
//        val url = intent.getStringExtra("url") ?: "https://www.halodoc.com/kesehatan/kesehatan-mental?srsltid=AfmBOorkbLRx59fGPVPRf6zv_gScL7MNqfiisvSySvOkZ6-0EOFYcjg6"
//        webView.loadUrl(url)
        webView.webViewClient= WebViewClient()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId){
            android.R.id.home->{
                finish()
                true
            }else ->super.onOptionsItemSelected(item)
        }
    }
    //Untuk membuat button back pada webview (<--)
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        }else {
            super.onBackPressed()
        }
    }
}
