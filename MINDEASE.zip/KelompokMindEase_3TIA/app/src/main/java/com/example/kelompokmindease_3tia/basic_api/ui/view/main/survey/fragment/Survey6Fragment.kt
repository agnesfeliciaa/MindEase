package com.example.kelompokmindease_3tia.basic_api.ui.view.main.survey.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.viewpager2.widget.ViewPager2
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_fragment.FragmentActivity
import com.example.kelompokmindease_3tia.databinding.FragmentSurvey5Binding
import androidx.lifecycle.ViewModelProvider
import com.example.kelompokmindease_3tia.basic_api.ui.viewmodel.SurveyViewModel
import com.example.kelompokmindease_3tia.databinding.FragmentSurvey6Binding

class Survey6Fragment : Fragment() {

    private var _binding: FragmentSurvey6Binding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: SurveyViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSurvey6Binding.inflate(inflater, container, false)

        // Inisialisasi ViewModel
        viewModel = ViewModelProvider(requireActivity()).get(SurveyViewModel::class.java)

        binding.buttonNext.setOnClickListener {
            val input = binding.sleepQuality.text.toString()

            if (input.isNotEmpty()) {
                val number = input.toIntOrNull()
                if (number == null) {
                    Toast.makeText(requireContext(), "Masukkan angka yang valid", Toast.LENGTH_SHORT).show()
                } else if (number < 0 || number > 5) {
                    Toast.makeText(requireContext(), "Isi sesuai rentang (0-5)", Toast.LENGTH_SHORT).show()
                } else {
                    // Simpan input ke ViewModel dengan key "sleep_quality"
                    viewModel.setAnswer("sleep_quality", number)

                    // Navigasi ke Survey7Fragment
                    (activity as? SurveyActivity)?.replaceFragment(Survey7Fragment())
                }
            } else {
                Toast.makeText(requireContext(), "Isi inputan", Toast.LENGTH_SHORT).show()
            }
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

//class Survey6Fragment : Fragment() {
//
//    private var _binding : FragmentSurvey6Binding? = null
//    private val binding get() = _binding!!
//
//    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View? {
//        _binding = FragmentSurvey6Binding.inflate(inflater, container, false)
//
//        binding.buttonNext.setOnClickListener {
//            val input1 = binding.sleepQuality.text.toString()
//
//            if (input1.isNotEmpty()) {
//                val number = input1.toIntOrNull()
//                if (number == null) {
//                    Toast.makeText(requireContext(), "Masukkan angka yang valid", Toast.LENGTH_SHORT).show()
//                } else if (number < 0 || number > 5) {
//                    Toast.makeText(requireContext(), "Isi sesuai rentang (0-5)", Toast.LENGTH_SHORT).show()
//                } else {
//                    (activity as? SurveyActivity)?.replaceFragment(Survey7Fragment())
//                }
//            } else {
//                Toast.makeText(requireContext(), "Isi inputan", Toast.LENGTH_SHORT).show()
//            }
//        }
//
//        return binding.root
//    }
//}