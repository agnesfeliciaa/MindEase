package com.example.kelompokmindease_3tia.basic_api.ui.view.main.more

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.kelompokmindease_3tia.FirstActivity
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.SecondActivity
import com.example.kelompokmindease_3tia.WebViewActivity
import com.example.kelompokmindease_3tia.basic_api.data.model.ListMoreModel
import com.example.kelompokmindease_3tia.basic_api.ui.adapter.ListMoreAdapter
import com.example.kelompokmindease_3tia.databinding.FragmentMoreBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MoreFragment : Fragment() {

    private var _binding : FragmentMoreBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentMoreBinding.inflate(inflater, container, false)
//        val view = inflater.inflate(R.layout.fragment_more, container, false)

//        setUpListMore(view)
//        setupFAB(view)
        setUpListMore(binding)
        setupFAB(binding)

//        val listView: ListView = view.findViewById(R.id.listViewMore)
//
//        val menuList= listOf(
//            ListMoreModel("Ceritakan keseharianmu", "Yuk tulis yang kamu alami hari ini"),
//            ListMoreModel("Tarik nafas, keluarkan", "Luangkan waktu, tenangkan pikiran"),
//            ListMoreModel("Sebutkan 5 benda di sekitar", "Apakah kamu sedang kurang baik?"),
//        )
//
//        //pemanggilan adapter context dll dari lst adapter
//        val adapter= ListMoreAdapter(this,menuList)
//        listView.adapter=adapter
//
//        //
//        listView.setOnItemClickListener{ parent, view, position, id ->
//            val selectedItem= menuList[position]
//
//            if(selectedItem.name=="Menu 5") {
//                Toast.makeText(
//                    this,
//                    "Redirect ke halaman detail ${selectedItem.name}",
//                    Toast.LENGTH_LONG
//                ).show()
//            }else {
//                Toast.makeText(this, "Kamu klik ${selectedItem.name}", Toast.LENGTH_LONG).show()
//            }
//        }
//
//        return view
        return binding.root
    }

//    private fun setupFAB(view: View){
//        val fab : FloatingActionButton = view.findViewById(R.id.fab)
//        fab.setOnClickListener{
//            showBottomSheetDialog()
//        }
//    }
    private fun setupFAB(binding: FragmentMoreBinding){
//        val fab : FloatingActionButton = view.findViewById(R.id.fab)
        binding.fab.setOnClickListener{
            showBottomSheetDialog()
        }
    }

    private fun showBottomSheetDialog(){
        val bottomSheetDialog = BottomSheetDialog(requireContext())
        val view = LayoutInflater.from(requireContext()).inflate(R.layout.bottom_sheet_layout, null)
        bottomSheetDialog.setContentView(view)
        bottomSheetDialog.show()

        initChip(view)
        initDatePicker(view)
    }

//    private fun setUpListMore(view:View){
//        val listMore: ListView = view.findViewById(R.id.listViewMore)
//        val items = listOf(
//            ListMoreModel("First Activity", "Klik untuk  berpindah ke first activity"),
//            ListMoreModel("Second Activity",  "Klik untuk  berpindah ke second activity"),
//            ListMoreModel("Web View Activity",  "Klik untuk  berpindah ke web view activity"),
//            )
//
//        listMore.adapter = ListMoreAdapter(requireContext(), items)
//
//        listMore.setOnItemClickListener{ parent, view, position, id ->
//            when(position) {
//                0 -> {
//                    startActivity(Intent(this.context,  FirstActivity::class.java))
//                }
//                1 -> {
//                    startActivity(Intent(this.context,  SecondActivity::class.java))
//                }
//                2 -> {
//                    startActivity(Intent(this.context,  WebViewActivity::class.java))
//                }
//            }
//        }
//    }

    private fun setUpListMore(binding: FragmentMoreBinding){
//        val listMore: ListView = view.findViewById(R.id.listViewMore)
        val items = listOf(
            ListMoreModel("First Activity", "Klik untuk  berpindah ke first activity"),
            ListMoreModel("Second Activity",  "Klik untuk  berpindah ke second activity"),
            ListMoreModel("Web View Activity",  "Klik untuk  berpindah ke web view activity"),
            )

        binding.listViewMore.adapter = ListMoreAdapter(requireContext(), items)

        binding.listViewMore.setOnItemClickListener{ parent, view, position, id ->
            when(position) {
                0 -> {
                    startActivity(Intent(this.context,  FirstActivity::class.java))
                }
                1 -> {
                    startActivity(Intent(this.context,  SecondActivity::class.java))
                }
                2 -> {
                    startActivity(Intent(this.context,  WebViewActivity::class.java))
                }
            }
        }
    }

//    private fun initChip(view: View){
//        val chipGroup : ChipGroup = view.findViewById(R.id.chipGroup)
//
//        val tags = listOf("Tag 1", "Tag 2", "Tag 3", "Tag 4")
//        for (tag in tags){
//            val chip = Chip(this.context).apply {
//                text = tag
//                isCheckable = true
//            }
//            chipGroup.addView(chip)
//        }
//    }

    private fun initChip(view: View){
        val chipGroup : ChipGroup = view.findViewById(R.id.chipGroup)

        val tags = listOf("Tag 1", "Tag 2", "Tag 3", "Tag 4")
        for (tag in tags){
            val chip = Chip(this.context).apply {
                text = tag
                isCheckable = true
            }
            chipGroup.addView(chip)
        }
    }

    private fun initDatePicker(view: View) {
        /*MaterialDialog & MaterialDatePicker*/
        val datePicker = MaterialDatePicker.Builder.datePicker()
            .setTitleText("Select date")
            .setSelection(MaterialDatePicker.todayInUtcMilliseconds())
            .build()

        val editTextDate: TextInputEditText = view.findViewById(R.id.textDate)
        editTextDate.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Material Design Dialog")
                .setMessage("Ini merupakan Contoh menerapkan Dialog Versi Material Design. Apakah anda ingin menampilkan kalender nya juga ?")
                .setNeutralButton("Batal") { dialog, which ->
                    // Respond to neutral button press
                }
                .setNegativeButton("Tidak") { dialog, which ->
                    // Respond to negative button press
                }
                .setPositiveButton("Ya") { dialog, which ->
                    datePicker.show(parentFragmentManager, "MATERIAL_DATE_PICKER")
                }
                .show()

        }

        datePicker.addOnPositiveButtonClickListener { selection ->
            // Format tanggal yang dipilih
            val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            val selectedDate = dateFormat.format(Date(selection))

            // Set tanggal ke TextInputEditText
            editTextDate.setText(selectedDate)
        }

    }

}