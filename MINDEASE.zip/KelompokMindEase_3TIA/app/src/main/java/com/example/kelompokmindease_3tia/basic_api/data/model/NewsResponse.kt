package com.example.kelompokmindease_3tia.basic_api.data.model

class NewsResponse (
    val status: String,
    val articles: List<Article>
)