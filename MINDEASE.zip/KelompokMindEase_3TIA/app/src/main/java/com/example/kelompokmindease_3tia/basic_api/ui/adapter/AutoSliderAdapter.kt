package com.example.kelompokmindease_3tia.basic_api.ui.adapter
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.example.kelompokmindease_3tia.databinding.SlideItemBinding
import com.squareup.picasso.Picasso
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class AutoSliderAdapter (
//    private val images:List<Int>,
//    private val images:List<String>,
    private val images:List<Any>,
    private val viewPager:ViewPager2,
    private val onClick: (Int) -> Unit
): RecyclerView.Adapter<AutoSliderAdapter.SliderViewHolder>(){

    private var currentPosition=0
    init {
        startAutoSlide()
    }
    class SliderViewHolder(val binding: SlideItemBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SliderViewHolder {
        val binding = SlideItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return SliderViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SliderViewHolder, position: Int) {
//        Picasso.get().load(images[position]).into(holder.binding.slideImage)
        val image = images[position] // Ambil elemen pada posisi tertentu
        if (image is String) {
            // Memuat URL eksternal dengan Picasso
            Picasso.get().load(image).into(holder.binding.slideImage)
        } else if (image is Int) {
            // Memuat resource drawable lokal
            holder.binding.slideImage.setImageResource(image)
        }
        holder.binding.slideImage.setOnClickListener {
            onClick(position) // Panggil callback saat gambar diklik
        }
    }

//    class SliderViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){
//        val imageView:ImageView=itemView.findViewById((R.id.slideImage))
//    }
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SliderViewHolder {
//        val view=LayoutInflater.from(parent.context).inflate(R.layout.slide_item,parent,false)
//        return SliderViewHolder(view)
//    }
//    override fun onBindViewHolder(holder:SliderViewHolder, position:Int){
////        holder.imageView.setImageResource(images[position])
//        Picasso.get().load(images[position]).into(holder.imageView)
//    }

    override fun getItemCount(): Int {
        return images.size
    }
    private fun startAutoSlide(){
        CoroutineScope(Dispatchers.Main).launch {
            while(true){
                delay(3000)
                currentPosition=(currentPosition+1) %itemCount
                viewPager.setCurrentItem(currentPosition,true)
            }
        }
    }
}