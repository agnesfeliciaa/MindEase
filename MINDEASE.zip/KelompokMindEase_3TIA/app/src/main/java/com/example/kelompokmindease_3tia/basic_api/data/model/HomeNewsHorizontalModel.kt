package com.example.kelompokmindease_3tia.basic_api.data.model

import retrofit2.http.Url

class HomeNewsHorizontalModel (
    val title:String,
//    val imagaUrl:String,
//    val imagaUrl:Int, //gambar dari drawable
    val imageUrl: Any,  // Ubah tipe ke Any untuk mendukung URL dan resource ID
    val isi:String,
    val background:String,
    val backgroundIsi:String,
    val url: String
)

