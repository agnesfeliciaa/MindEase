package com.example.kelompokmindease_3tia.basic_recyclerview

data class ItemModel(
    val imageUrl: String,
    val nama: String,
    val menit: String,
)
