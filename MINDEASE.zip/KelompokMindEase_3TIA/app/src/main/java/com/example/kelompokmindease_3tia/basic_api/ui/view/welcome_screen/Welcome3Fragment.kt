package com.example.kelompokmindease_3tia.basic_api.ui.view.welcome_screen

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.kelompokmindease_3tia.R

class Welcome3Fragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_welcome3, container, false)

//        val imgBack : ImageView =view.findViewById(R.id.imageBack)
//
//        imgBack.setOnClickListener {
//            (activity as? WelcomeScreenActivity)?.replaceFragment(Welcome2Fragment())
//        }

        return view
    }
}
