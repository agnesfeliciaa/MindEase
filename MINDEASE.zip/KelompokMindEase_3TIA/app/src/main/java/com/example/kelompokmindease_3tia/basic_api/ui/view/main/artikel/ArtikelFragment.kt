package com.example.kelompokmindease_3tia.basic_api.ui.view.main.artikel

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_api.data.model.ArtikelRequest
import com.example.kelompokmindease_3tia.basic_api.data.model.ArtikelTerkaitModel
import com.example.kelompokmindease_3tia.basic_api.data.model.ArtikelTrendingModel
import com.example.kelompokmindease_3tia.basic_api.data.network.RetrofitInstance
import com.example.kelompokmindease_3tia.basic_api.data.repository.ArtikelRepository
import com.example.kelompokmindease_3tia.basic_api.ui.adapter.ArtikelTerkaitAdapter
import com.example.kelompokmindease_3tia.basic_api.ui.adapter.ArtikelTrendingAdapter
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.meditasi.MeditasiFokusFragment
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.meditasi.MeditasiPagiFragment
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.meditasi.MeditasiSemuaFragment
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.meditasi.MeditasiTidurFragment
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.meditasi.PutarStressdanKecemasanActivity
import com.example.kelompokmindease_3tia.basic_api.ui.viewmodel.ArtikelViewModel
import com.example.kelompokmindease_3tia.basic_api.utils.Resource
import com.example.kelompokmindease_3tia.basic_api.utils.ViewModelFactory
import com.example.kelompokmindease_3tia.databinding.FragmentArtikelBinding
import com.google.android.material.snackbar.Snackbar

class ArtikelFragment : Fragment() {

    private var _binding: FragmentArtikelBinding? = null
    private val binding get() = _binding!!

    private val artikelViewModel: ArtikelViewModel by activityViewModels {
        ViewModelFactory(ArtikelViewModel::class.java) {
            val repository = ArtikelRepository(
                RetrofitInstance.getCrudApi()
            )
            ArtikelViewModel(repository)
        }
    }

    private lateinit var adapter: ArtikelTerkaitAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentArtikelBinding.inflate(inflater, container, false)

        loadFragment(ArtikelSemuaFragment())


        // Mengatur listener pada navbarToggleGroup
        binding.navbarToggleGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) { // Hanya diproses jika tombol benar-benar dipilih
                when (checkedId) {
                    binding.btnSemua.id -> {
                        loadFragment(ArtikelSemuaFragment())
                        updateButtonStyles(binding.btnSemua)
                    }

                    binding.btnStress.id -> {
                        loadFragment(ArtikelStressFragment())
                        updateButtonStyles(binding.btnStress)
                    }

                    binding.btnRekomendasi.id -> {
                        loadFragment(ArtikelRekomendasiFragment())
                        updateButtonStyles(binding.btnRekomendasi)
                    }
                }
            }
        }
        return binding.root
    }


    private fun loadFragment(fragment: Fragment) {
        // Menggunakan childFragmentManager untuk fragment dalam fragment
        childFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    /**
     * Fungsi untuk memperbarui gaya tombol yang dipilih
     */
    private fun updateButtonStyles(selectedButton: View) {
        // Reset gaya semua tombol
        resetButtonStyles()

        // Gaya tombol yang dipilih
        selectedButton.setBackgroundColor(resources.getColor(R.color.selectedBackgroundColor, null))
        (selectedButton as? com.google.android.material.button.MaterialButton)?.let {
            it.setTextColor(resources.getColor(R.color.selectedTextColor, null))
            it.strokeColor = resources.getColorStateList(R.color.selectedBorderColor, null)
        }
    }



    /**
     * Fungsi untuk mereset gaya semua tombol ke status tidak dipilih
     */
    private fun resetButtonStyles() {
        val buttons = listOf(
            binding.btnSemua,
            binding.btnStress,
            binding.btnRekomendasi,
        )

        buttons.forEach { button ->
            button.setBackgroundColor(resources.getColor(R.color.unselectedBackgroundColor, null))
            (button as? com.google.android.material.button.MaterialButton)?.let {
                it.setTextColor(resources.getColor(R.color.unselectedTextColor, null))
                it.strokeColor = resources.getColorStateList(R.color.unselectedBorderColor, null)
            }
        }
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}