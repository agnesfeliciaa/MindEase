package com.example.kelompokmindease_3tia.basic_api.data.network

import com.example.kelompokmindease_3tia.basic_api.data.model.ArtikelRequest
import com.example.kelompokmindease_3tia.basic_api.data.model.ArtikelResponse
import com.example.kelompokmindease_3tia.basic_api.data.model.ArtikelTerkaitModel
import com.example.kelompokmindease_3tia.basic_api.data.model.User
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Query

interface ApiService {
    @GET("users")
    suspend fun getUsers(): List<User>

    @POST("artikel")
    suspend fun createArtikel(
        @Header("Authorization") token: String,
        @Body artikels: List<ArtikelRequest>,
    ): ArtikelResponse

    @GET("artikel")
    suspend fun getArtikels(
        @Header("Authorization") token: String
    ): ArtikelResponse

}