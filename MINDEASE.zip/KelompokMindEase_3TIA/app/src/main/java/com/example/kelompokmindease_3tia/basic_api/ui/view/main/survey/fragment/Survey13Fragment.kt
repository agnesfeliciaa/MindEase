package com.example.kelompokmindease_3tia.basic_api.ui.view.main.survey.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_api.data.model.SurveyResponse
import com.example.kelompokmindease_3tia.basic_api.data.network.ApiClient
import com.example.kelompokmindease_3tia.basic_api.ui.viewmodel.SurveyViewModel
import com.example.kelompokmindease_3tia.databinding.FragmentSurvey13Binding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Survey13Fragment : Fragment() {

    private var _binding: FragmentSurvey13Binding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: SurveyViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSurvey13Binding.inflate(inflater, container, false)

        // Initialize ViewModel
        viewModel = ViewModelProvider(requireActivity()).get(SurveyViewModel::class.java)

        binding.buttonNext.setOnClickListener {
            // Ambil inputan terakhir (misalnya inputan di field "teacherStudentRelationship")
            val input1 = binding.socialSupport.text.toString()

            // Validasi inputan terakhir
            if (input1.isNotEmpty()) {
                val number = input1.toIntOrNull()

                // Cek apakah input valid
                if (number == null) {
                    Toast.makeText(
                        requireContext(),
                        "Masukkan angka yang valid",
                        Toast.LENGTH_SHORT
                    ).show()
                } else if (number < 0 || number > 3) {
                    Toast.makeText(
                        requireContext(),
                        "Isi sesuai rentang (0-3)",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    // Simpan input terakhir ke ViewModel
                    viewModel.setAnswer("social_support", number)

                    // Ambil semua jawaban dari ViewModel
                    val allAnswers = viewModel.getAllAnswers()
                    Log.d(
                        "Survey13Fragment",
                        "All answers to send: $allAnswers"
                    )  // Log semua jawaban yang dikumpulkan

                    // Cek apakah ada jawaban yang disimpan di ViewModel
                    if (allAnswers.isNotEmpty()) {
                        Log.d(
                            "Survey13Fragment",
                            "Sending data to API..."
                        )  // Log sebelum kirim data ke API

                        // Kirim data ke API
                        ApiClient.instance.submitSurvey(allAnswers)
                            .enqueue(object : Callback<SurveyResponse> {
                                override fun onResponse(
                                    call: Call<SurveyResponse>,
                                    response: Response<SurveyResponse>
                                ) {
                                    Log.d(
                                        "Survey13Fragment",
                                        "API response received: ${response.code()}"
                                    ) // Log response code

                                    if (response.isSuccessful) {
                                        val prediction = response.body()?.prediction
                                        Log.d(
                                            "Survey13Fragment",
                                            "Prediction received: $prediction"
                                        ) // Log prediction

                                        // Berdasarkan nilai prediksi, arahkan ke fragmen yang sesuai
                                        when (prediction) {
                                            0 -> {
                                                Log.d(
                                                    "Survey13Fragment",
                                                    "Redirecting to SurveyHasilHFragment"
                                                )
                                                (activity as? SurveyActivity)?.replaceFragment(
                                                    SurveyHasilHFragment()
                                                )
                                            }

                                            1 -> {
                                                Log.d(
                                                    "Survey13Fragment",
                                                    "Redirecting to SurveyHasilKFragment"
                                                )
                                                (activity as? SurveyActivity)?.replaceFragment(
                                                    SurveyHasilKFragment()
                                                )
                                            }

                                            2 -> {
                                                Log.d(
                                                    "Survey13Fragment",
                                                    "Redirecting to SurveyHasilMFragment"
                                                )
                                                (activity as? SurveyActivity)?.replaceFragment(
                                                    SurveyHasilMFragment()
                                                )
                                            }

                                            else -> {
                                                Log.e(
                                                    "Survey13Fragment",
                                                    "Invalid prediction value: $prediction"
                                                )
                                                Toast.makeText(
                                                    context,
                                                    "Prediction tidak valid",
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                            }
                                        }
                                    } else {
                                        Log.e(
                                            "Survey13Fragment",
                                            "Response error: ${response.message()}"
                                        )
                                        Toast.makeText(
                                            context,
                                            "Response error: ${response.message()}",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }

                                override fun onFailure(
                                    call: Call<SurveyResponse>,
                                    t: Throwable
                                ) {
                                    Log.e(
                                        "Survey13Fragment",
                                        "Failed to submit data: ${t.message}"
                                    )
                                    Toast.makeText(
                                        context,
                                        "Gagal mengirim data: ${t.message}",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            })
                    } else {
                        Log.w("Survey13Fragment", "No answers provided.")
                        Toast.makeText(
                            context,
                            "Silakan lengkapi semua jawaban sebelum melanjutkan.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            } else {
                Toast.makeText(requireContext(), "Isi inputan", Toast.LENGTH_SHORT).show()
            }
        }

        // Pastikan return binding.root berada di akhir onCreateView
        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null // Clean up binding to avoid memory leaks
    }
}
