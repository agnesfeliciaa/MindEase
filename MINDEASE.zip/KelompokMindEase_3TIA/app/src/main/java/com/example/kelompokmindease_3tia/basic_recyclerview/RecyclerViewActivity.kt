package com.example.kelompokmindease_3tia.basic_recyclerview

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kelompokmindease_3tia.basic_recyclerview.ItemAdapter
import com.example.kelompokmindease_3tia.R

class RecyclerViewActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ItemAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_recycler_view)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        val items = listOf(
            ItemModel("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSIrYN4w-TJscbthBQi5IFOjNyvL0DcLkndSQ&s", "Diri yang lebih baik", "6 Menit"),
            ItemModel("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRZrjkEzWGt6CntX7rrgSM9wBjn3_U-h5Mi2g&s", "Stress dan Kecemasan", "6 Menit"),
            ItemModel("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqCAABph_zt31ami0s0DnlAzeMZHWwY21bHw&s", "Tidur Lebih Nyeyak", "6 Menit"),
        )

//        adapter = ItemAdapter(items)
//        recyclerView.adapter
        adapter = ItemAdapter(items)
        recyclerView.adapter = adapter

    }
}