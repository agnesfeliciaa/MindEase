package com.example.kelompokmindease_3tia.basic_api.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_api.data.model.ListMoreModel

class ListMoreAdapter (
    context: Context,
    private  val menuList:List<ListMoreModel>
) : ArrayAdapter<ListMoreModel>(context, 0, menuList) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.list_more_item,parent, false)

        val menuItem = getItem(position)
        val textName : TextView = view.findViewById(R.id.textName)
        val textDesc : TextView = view.findViewById(R.id.textDesc)

        menuItem?.let{
            textName.text = it.name
            textDesc.text = it.desc
        }

        return view
    }
}