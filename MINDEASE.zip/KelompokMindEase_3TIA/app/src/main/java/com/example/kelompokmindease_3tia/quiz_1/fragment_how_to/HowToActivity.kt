package com.example.kelompokmindease_3tia.quiz_1.fragment_how_to

import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.viewpager2.widget.ViewPager2
import com.example.kelompokmindease_3tia.R
import com.tbuonomo.viewpagerdotsindicator.DotsIndicator

class HowToActivity : AppCompatActivity() {

    private lateinit var viewPager: ViewPager2
    private lateinit var dotsIndicator: DotsIndicator
    private lateinit var btnSkip: Button
    private lateinit var btnNext: Button

    override fun onCreate(savedInstanceState: Bundle?) {

        var toolbar: Toolbar

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_how_to)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //inisialisasi toolbar
        toolbar=findViewById(R.id.toolbar)
        toolbar.setTitle("Kesehatan Mental")
        setSupportActionBar(toolbar)

        //inisialisasi tombol back
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)

        viewPager=findViewById(R.id.ViewPager)


        val fragmentList= listOf(HowTo1Fragment(), HowTo2Fragment(), HowTo3Fragment(), HowTo4Fragment())
        val adapter= HowToAdapter(this, fragmentList)


        viewPager.adapter=adapter

        dotsIndicator=findViewById(R.id.dots_indicator)

        dotsIndicator.attachTo(viewPager)


        btnSkip=findViewById(R.id.btnSkip)
        btnSkip.setOnClickListener{
            finishWelcomeScreen()
        }

        btnNext=findViewById(R.id.btnNext)
        btnNext.setOnClickListener {
            if (viewPager.currentItem < fragmentList.size - 1) {
                viewPager.currentItem += 1
            } else {
                finishWelcomeScreen()
            }
        }
//
        viewPager.registerOnPageChangeCallback(object: ViewPager2.OnPageChangeCallback(){
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                if (position == fragmentList.size - 1) {
                    btnNext.text = "Finish"
//                    btnSkip.visibility = View.GONE
                } else {
                    btnSkip.text = "Skip"
//                    btnSkip.visibility = View.GONE
                }
            }
        })
    }


    private fun finishWelcomeScreen(){
//        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId){
            android.R.id.home->{
                finish()
                true
            }else ->super.onOptionsItemSelected(item)
        }
    }
//    //Untuk membuat button back pada webview (<--)
//    override fun onBackPressed() {
//        if (viewPager.canGoBack()) {
//            viewPager.goBack()
//        }else {
//            super.onBackPressed()
//        }
//    }
}
