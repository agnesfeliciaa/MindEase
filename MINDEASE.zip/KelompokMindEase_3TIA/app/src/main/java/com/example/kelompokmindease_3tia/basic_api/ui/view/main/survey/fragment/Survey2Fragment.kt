package com.example.kelompokmindease_3tia.basic_api.ui.view.main.survey.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.kelompokmindease_3tia.basic_api.ui.viewmodel.SurveyViewModel
import com.example.kelompokmindease_3tia.databinding.FragmentSurvey2Binding

class Survey2Fragment : Fragment() {
    private var _binding: FragmentSurvey2Binding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: SurveyViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSurvey2Binding.inflate(inflater, container, false)

        // Inisialisasi ViewModel
        viewModel = ViewModelProvider(requireActivity()).get(SurveyViewModel::class.java)

        binding.buttonNext.setOnClickListener {
            val input = binding.selfEsteem.text.toString()

            if (input.isNotEmpty()) {
                val number = input.toIntOrNull()
                if (number == null) {
                    Toast.makeText(requireContext(), "Masukkan angka yang valid", Toast.LENGTH_SHORT).show()
                } else if (number < 0 || number > 30) {
                    Toast.makeText(requireContext(), "Isi sesuai rentang (0-30)", Toast.LENGTH_SHORT).show()
                } else {
                    // Simpan input ke ViewModel dengan key "self_esteem"
                    viewModel.setAnswer("self_esteem", number)

                    // Navigasi ke Survey3Fragment
                    (activity as? SurveyActivity)?.replaceFragment(Survey3Fragment())
                }
            } else {
                Toast.makeText(requireContext(), "Isi inputan", Toast.LENGTH_SHORT).show()
            }
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
