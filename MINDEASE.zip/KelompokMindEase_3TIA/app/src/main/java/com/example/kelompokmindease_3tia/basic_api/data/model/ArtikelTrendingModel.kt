package com.example.kelompokmindease_3tia.basic_api.data.model

class ArtikelTrendingModel (
    val imageUrl : Any,
    val jenis : String,
    val judul : String,
    val tanggal : String,
    val menit : String,
    val url : String
)