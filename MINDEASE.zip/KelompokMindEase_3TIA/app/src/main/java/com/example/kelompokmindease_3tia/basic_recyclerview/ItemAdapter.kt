package com.example.kelompokmindease_3tia.basic_recyclerview

import android.content.ClipData.Item
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_recyclerview.ItemModel
import com.squareup.picasso.Picasso

class ItemAdapter(
    private val mList:List<ItemModel>
):RecyclerView.Adapter<ItemAdapter.ViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemAdapter.ViewHolder {
        val view=LayoutInflater.from(parent.context).inflate(R.layout.list_card_view, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemAdapter.ViewHolder, position: Int) {
        val item = mList[position]
        //set image based on item.imageUrl -->library picasso
        Picasso.get().load(item.imageUrl).into(holder.imageView)
        //set description based on item.description
        holder.textNama.text = item.nama
        holder.textMenit.text = item.menit

        //orinttt cobaa printtt
        println("Loading item pada position = $position")
    }

    override fun getItemCount(): Int {
        return mList.size
    }
    class ViewHolder(ItemView: View) :RecyclerView.ViewHolder(ItemView){
        val imageView:ImageView=itemView.findViewById(R.id.imageView)
        val textNama:TextView=itemView.findViewById(R.id.textNama)
        val textMenit:TextView=itemView.findViewById(R.id.textMenit)
    }
}