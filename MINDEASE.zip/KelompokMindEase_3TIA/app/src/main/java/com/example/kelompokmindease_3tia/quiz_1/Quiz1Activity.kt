package com.example.kelompokmindease_3tia.quiz_1

import android.content.Intent
import android.os.Bundle
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.quiz_1.fragment_how_to.HowToActivity

class Quiz1Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_quiz1)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val listView: ListView =findViewById(R.id.listView)
        val quiz1List= listOf(
            Quiz1Model("Menghitung Lingkaran", R.drawable.ic_circle_blue),
            Quiz1Model("Cara Membuat Mie Rebus",  R.drawable.ic_mkn),
        )

        //pemanggilan adapter context dll dari lst adapter
        val adapter= Quiz1Adapter(this,quiz1List)
        listView.adapter=adapter

        //
        listView.setOnItemClickListener{ parent, view, position, id ->
            val selectedItem= quiz1List[position]

            if(selectedItem.name=="Cara Membuat Mie Rebus") {
//                Toast.makeText(
//                    this,
//                    "Redirect ke halaman detail ${selectedItem.name}",
//                    Toast.LENGTH_LONG
//                ).show()
                val i = Intent(this, HowToActivity::class.java)
                startActivity(i)
            }else {
                Toast.makeText(this, "Kamu klik ${selectedItem.name}", Toast.LENGTH_LONG).show()
            }
        }

    }
}