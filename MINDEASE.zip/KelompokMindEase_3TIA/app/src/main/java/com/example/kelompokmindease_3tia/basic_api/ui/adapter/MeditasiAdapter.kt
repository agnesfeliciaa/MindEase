package com.example.kelompokmindease_3tia.basic_api.ui.adapter
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.kelompokmindease_3tia.basic_api.data.model.MeditasiModel
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.meditasi.PutarDiriyangLebihBaikActivity
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.meditasi.PutarStressdanKecemasanActivity
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.meditasi.PutarTidurLebihNyenyakActivity
import com.example.kelompokmindease_3tia.databinding.MeditasiCardViewBinding
import com.squareup.picasso.Picasso

class MeditasiAdapter(
//    private val mList:List<HomeNewsHorizontalModel>
    private var mList:List<MeditasiModel>
):RecyclerView.Adapter<MeditasiAdapter.ViewHolder>(){

    fun updateData(newItems: List<MeditasiModel>){
        mList = newItems
        notifyDataSetChanged()
    }

    class ViewHolder(val binding:MeditasiCardViewBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
//        val view=LayoutInflater.from(parent.context).inflate(R.layout.home_new_item_horizontal, parent, false)
//        return ViewHolder(view)
        val  binding = MeditasiCardViewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = mList[position]

        // Cek tipe `imagaUrl` untuk menentukan cara memuat gambar
        if (item.imageUrl is String) {
            // Memuat URL eksternal dengan Picasso
            Picasso.get().load(item.imageUrl as String).into(holder.binding.imageView)
        } else if (item.imageUrl is Int) {
            // Memuat resource drawable lokal
            holder.binding.imageView.setImageResource(item.imageUrl as Int)
        }
        //set description based on item.description
        holder.binding.textNama.text = item.nama
        holder.binding.textMenit.text = item.menit
//        atur warna background
        //orinttt cobaa printtt
        //println("Loading item pada position = $position")

        holder.binding.imagePlay.setOnClickListener {
            val context = holder.itemView.context
            val intent = when (item.nama) {
                "Diri yang lebih baik" -> Intent(context, PutarDiriyangLebihBaikActivity::class.java)
                "Stress dan Kecemasan" -> Intent(context, PutarStressdanKecemasanActivity::class.java)
                "Tidur Lebih Nyenyak" -> Intent(context, PutarTidurLebihNyenyakActivity::class.java)
                else -> null
            }
            intent?.let {
                context.startActivity(it)
            }
        }

    }
    override fun getItemCount(): Int {
        return mList.size
    }
}