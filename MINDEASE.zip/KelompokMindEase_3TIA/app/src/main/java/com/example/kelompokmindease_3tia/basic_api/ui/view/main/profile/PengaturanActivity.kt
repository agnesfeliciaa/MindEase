package com.example.kelompokmindease_3tia.basic_api.ui.view.main.profile

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.kelompokmindease_3tia.databinding.ActivityPengaturanBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class PengaturanActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPengaturanBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPengaturanBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val userId = FirebaseAuth.getInstance().currentUser?.uid

        if (userId != null) {
            FirebaseFirestore.getInstance().collection("users").document(userId).get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val username = document.getString("username")
                        val phone = document.getString("phone")

                        binding.inputUsername.setText(username)
                        binding.inputPhone.setText(phone)
                    }
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Failed to load user data", Toast.LENGTH_SHORT).show()
                }
        }

        binding.textEditUsername.setOnClickListener {
            val newUsername = binding.inputUsername.text.toString()
            if (newUsername.isNotEmpty() && userId != null) {
                FirebaseFirestore.getInstance().collection("users").document(userId)
                    .update("username", newUsername)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Username updated successfully", Toast.LENGTH_SHORT).show()
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Failed to update username", Toast.LENGTH_SHORT).show()
                    }
            } else {
                Toast.makeText(this, "Username cannot be empty", Toast.LENGTH_SHORT).show()
            }
        }

        binding.textEditPhone.setOnClickListener {
            val newPhone = binding.inputPhone.text.toString()
            if (newPhone.isNotEmpty() && userId != null) {
                FirebaseFirestore.getInstance().collection("users").document(userId)
                    .update("phone", newPhone)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Phone number updated successfully", Toast.LENGTH_SHORT).show()
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Failed to update phone number", Toast.LENGTH_SHORT).show()
                    }
            } else {
                Toast.makeText(this, "Phone number cannot be empty", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnBack.setOnClickListener {
            finish()
        }
    }
}
