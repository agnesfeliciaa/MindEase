package com.example.kelompokmindease_3tia

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.kelompokmindease_3tia.basic_fragment.FragmentActivity
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.home.NotifikasiHomeActivity
import com.example.kelompokmindease_3tia.basic_recyclerview.RecyclerViewActivity
import com.example.kelompokmindease_3tia.basic_api.ui.view.welcome_screen.WelcomeScreenActivity
import com.google.android.material.snackbar.Snackbar


class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_second)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val textName: TextView = findViewById(R.id.name)





        //Ambil Preferences
        val sharPref= getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val username=sharPref.getString("username",null)
        textName.setText(username.toString())

//        //karena telah menggunakan shared preferences jadi cara manual dibawah di comment saja
//        val name = intent.getStringExtra("name")
//        textName.setText(name.toString())

        val btnBack: Button = findViewById(R.id.btnBack)
        btnBack.setOnClickListener {
            finish()
        }
        //Membuat snackbar 1
        val btnSnackBar1: Button = findViewById(R.id.btnSnackBar1)
        btnSnackBar1.setOnClickListener {
            //belum menggunakan private function
            val view = this.findViewById<View>(android.R.id.content)
            val snackbar = Snackbar.make(view, "Hallo, Ini Snack Aness", Snackbar.LENGTH_LONG)

            snackbar.setAction("Undo") {
                Toast.makeText(this, "Tombol Undo di-klik", Toast.LENGTH_LONG) //action untuk undo menggunakan toast
            }
            snackbar.show()
        }

        //Membuat snackbar 2
        val btnSnackBar2: Button = findViewById(R.id.btnSnackBar2)
        btnSnackBar2.setOnClickListener {
            //Pemanggilan showSnackBar dari private function
            showSnackBar("Hai, ini pemanggilan  dari fun showSnackBar()")
        }

        //Membuat Alert Dialog
        val btnAlertDialog: Button = findViewById(R.id.btnAlertDialog)
        btnAlertDialog.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Confirm")
                .setMessage("Are Your Sure?")
                //kondisi YES
                .setPositiveButton("Yes"){dialogInterface, which ->
                    dialogInterface.dismiss()
                    showSnackBar("Okay!")
                } //kondisi jika NO
                .setNegativeButton("No", null)
                .show()
        }

        //Membuat Web View
        val btnWebView:Button=findViewById(R.id.btnWebView)
        btnWebView.setOnClickListener{
            val i = Intent(this, WebViewActivity::class.java)
            startActivity(i)
        }

        //membuat button fragment
        val btnBasicFragment:Button=findViewById(R.id.btnBasicFragment)
        btnBasicFragment.setOnClickListener{
            val i = Intent(this,FragmentActivity::class.java)
            startActivity(i)
        }


        //button viewpager
        val btnViewPager:Button=findViewById(R.id.btnViewPager)
        btnViewPager.setOnClickListener{
            val i = Intent(this, WelcomeScreenActivity::class.java)
            startActivity(i)
        }

        //button ListView
        val btnListView:Button=findViewById(R.id.btnListView)
        btnListView.setOnClickListener{
            val i = Intent(this, NotifikasiHomeActivity::class.java)
            startActivity(i)
        }

        //button Recycle View
        val btnRecycleView:Button=findViewById(R.id.btnRecycleView)
        btnRecycleView.setOnClickListener{
            val i = Intent(this,RecyclerViewActivity::class.java)
            startActivity(i)
        }
    }
    //Menggunakan private function untuk dipanggil pada btn Snack bar (logika agar lebih rapi)
    private fun showSnackBar(message: String){
        val view = this.findViewById<View>(android.R.id.content)
        val snackbar = Snackbar.make(view, message, Snackbar.LENGTH_LONG)
        snackbar.setAction("Undo"){
            Toast.makeText(this,"Tombol Undo di-klik", Toast.LENGTH_LONG)
        }
        snackbar.show()
    }
}








