package com.example.kelompokmindease_3tia.basic_fragment

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.webkit.WebView
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_recyclerview.RecyclerViewActivity
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.artikel.ArtikelFragment
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.profile.ProfileFragment

class FragmentActivity : AppCompatActivity() {
    private lateinit var toolbar: Toolbar


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_fragment)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

//        val btnFragment1: Button =findViewById(R.id.btnFragment1)
//        val btnFragment2: Button =findViewById(R.id.btnFragment2)
//        val btnFragment3: Button =findViewById(R.id.btnFragment3)

//        btnFragment1.setOnClickListener{
//            replaceFragment(FragmentFirst())
//        }
//        btnFragment2.setOnClickListener{
//            replaceFragment(FragmentSecond())
//        }
//        btnFragment3.setOnClickListener{
//            replaceFragment(FragmentThird())
//        }



        //set Default Fragment (jadi otomatis saat masuk fragment activity, langsung arah ke fragment 1
        supportFragmentManager.beginTransaction()
            .replace(R.id.frameContainer,FragmentHome())
            .commit()

        val imgHome: ImageView = findViewById(R.id.imageHome)
        val txtHome :TextView = findViewById(R.id.textHome)
        imgHome.setOnClickListener{
            replaceFragment(FragmentHome())
        }
        txtHome.setOnClickListener{
            replaceFragment(FragmentHome())
        }

        val imgInsight: ImageView = findViewById(R.id.imageInsight)
        val txtInsight :TextView = findViewById(R.id.textInsight)
        imgInsight.setOnClickListener{
            replaceFragment(FragmentInsight())
        }
        txtInsight.setOnClickListener{
            replaceFragment(FragmentInsight())
        }

        val imgMeditation: ImageView = findViewById(R.id.imageMeditation)
        val txtMeditation :TextView = findViewById(R.id.textMeditation)
        imgMeditation.setOnClickListener{
            replaceFragment(FragmentMeditation())
        }
        txtMeditation.setOnClickListener{
            replaceFragment(FragmentMeditation())
        }

        val imgJournal: ImageView = findViewById(R.id.imageJournal)
        val txtJournal :TextView = findViewById(R.id.textJournal)
        imgJournal.setOnClickListener{
            replaceFragment(com.example.kelompokmindease_3tia.basic_api.ui.view.main.artikel.ArtikelFragment())
        }
        txtJournal.setOnClickListener{
            replaceFragment(com.example.kelompokmindease_3tia.basic_api.ui.view.main.artikel.ArtikelFragment())
        }

        val imgProfile: ImageView = findViewById(R.id.imageProfile)
        val txtProfile :TextView = findViewById(R.id.textProfile)
        imgProfile.setOnClickListener{
            replaceFragment(ProfileFragment())
        }
        txtProfile.setOnClickListener{
            replaceFragment(ProfileFragment())
        }



//        //inisialisasi toolbar
//        toolbar=findViewById(R.id.toolbar)
//        toolbar.setTitle("Basic Fragment")
//        setSupportActionBar(toolbar)
//
//
//        //inisialisasi tombol back
//        supportActionBar?.setDisplayHomeAsUpEnabled(true)
//        supportActionBar?.setDisplayShowHomeEnabled(true)
    }
    //arahkan jadi public
    public fun replaceFragment(fragment: Fragment){
        val transaction=supportFragmentManager.beginTransaction()
        transaction.replace(R.id.frameContainer, fragment)
        //karena adanya perintah tersbut, agar kita membuat tumpukan stack untuk activity, jadi kebaca tiap tumpukan, jadi jika kita klik masing2 fragment jika back, maka akan back sesuai klik tadi, baru bisa ke home. jadi harus ada backtoStack, jadi ga langsung kill activity/finisih
        transaction.addToBackStack(null)
        transaction.commit()
    }
//    //untuk toolbar
//    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//        return when (item.itemId){
//            android.R.id.home->{
//                finish()
//                true
//            }else ->super.onOptionsItemSelected(item)
//        }
//    }
//    //untuk membuat button back pada webview (<--)
//    override fun onBackPressed() {
//        if (webView.canGoBack()) {
//            webView.goBack()
//        }else {
//            super.onBackPressed()
//        }
//    }
}
