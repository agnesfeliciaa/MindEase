package com.example.kelompokmindease_3tia.basic_api.data.model

class Article (
    val title: String,
    val author : String,
    val description: String,
    val url: String,
    val urlToImage: String
)