package com.example.kelompokmindease_3tia.basic_api.ui.adapter

import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.survey.fragment.SurveyActivity

class SurveyAdapter (
    activity: SurveyActivity,
    private val fragments: List<Fragment>
): FragmentStateAdapter(activity) {


    override fun getItemCount(): Int {
        return fragments.size
    }

    override fun createFragment(position: Int): Fragment {
        return fragments[position]
    }
}