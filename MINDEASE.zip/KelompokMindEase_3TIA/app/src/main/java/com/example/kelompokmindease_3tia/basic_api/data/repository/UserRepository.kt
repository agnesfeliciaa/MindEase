package com.example.kelompokmindease_3tia.basic_api.data.repository

import com.example.kelompokmindease_3tia.basic_api.data.model.NewsResponse
import com.example.kelompokmindease_3tia.basic_api.data.model.User
import com.example.kelompokmindease_3tia.basic_api.data.network.ApiService


class UserRepository(private val api:ApiService) {
    suspend fun fetchUsers(): List<User> {
        return api.getUsers()
    }
}
//class UserRepository(private val api:ApiService) {
//    suspend fun fetchUsers(): NewsResponse {
//        return api.getUsers()
//    }
//}
