package com.example.kelompokmindease_3tia.basic_api.ui.view


import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.kelompokmindease_3tia.ForgotActivity
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_api.data.firebase.FirebaseAuthService
import com.example.kelompokmindease_3tia.basic_api.data.repository.FirebaseRepository
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.MainActivity
import com.example.kelompokmindease_3tia.basic_api.ui.viewmodel.FirebaseViewModel
import com.example.kelompokmindease_3tia.basic_api.utils.Resource
import com.example.kelompokmindease_3tia.basic_api.utils.ViewModelFactory
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore


class LoginActivity : AppCompatActivity() {

    private val firebaseViewModel: FirebaseViewModel by viewModels {
        ViewModelFactory(FirebaseViewModel::class.java) {
            val repository = FirebaseRepository(FirebaseAuthService())
            FirebaseViewModel(repository)
        }
    }
    private val firestore = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        //Deklarasi Variabel
        //val sharPref : SharedPreferences= getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val sharPref = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val inputPasswordL: TextInputEditText = findViewById(R.id.inputPasswordL)
        val btnLogin: Button = findViewById(R.id.btnLogin)
        val regisL: TextView = findViewById(R.id.regisL)
        val inputEmail: TextInputEditText = findViewById(R.id.inputEmailL)
        val inputPassword: TextInputEditText = findViewById(R.id.inputPasswordL)

        // Jika user sudah login sebelumnya, langsung ambil data dari Firebase dan pindah ke MainActivity
        val currentUser = FirebaseAuth.getInstance().currentUser
        if (currentUser != null) {
            fetchUserDataAndProceed(currentUser.uid)
        }

        //penggunaan intent ke RegistrasiAct dengan click textView Regis pada Login(bagian belum punya akun?)
        regisL.setOnClickListener {
            val i = Intent(this, RegisterActivity::class.java)
            startActivity(i)

        }

        //button Login untuk arah ke Intent baru dengan pengambilan data
        //cek flag isLogin
//        val isLogin = sharPref.getString("isLogin", null)
//        val isLogin = FirebaseAuth.getInstance().currentUser != null
//        if (isLogin) {
//            //Pemanggilan Intent untuk berpindah ke Main ACTIVIY
//            val i = Intent(this, com.example.kelompokmindease_3tia.basic_api.ui.view.main.MainActivity::class.java)
//            startActivity(i)
//            finish()
//        }

        //button login baru saat ada regis
        btnLogin.setOnClickListener {
            val email = inputEmail.text.toString().trim()
            val password = inputPassword.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "All fields are required.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            firebaseViewModel.login(email, password)

        }



//        firebaseViewModel.loginState.observe(this) { resource ->
//            when (resource) {
//                is Resource.Loading -> {
//                    Log.d("Firebase", "Logging in...")
//                }
//                is Resource.Success -> {
//                    val intent = Intent(this, MainActivity::class.java)
//                    startActivity(intent)
//                    finish()
//                }
//                is Resource.Error -> {
//                    Toast.makeText(this, resource.message, Toast.LENGTH_SHORT).show()
//                }
//                else -> {}
//            }
//        }
//    }
//}
// Observasi hasil login dari ViewModel
        firebaseViewModel.loginState.observe(this) { resource ->
            when (resource) {
                is Resource.Loading -> {
                    Log.d("Firebase", "Logging in...")
                }
                is Resource.Success -> {
                    val userId = FirebaseAuth.getInstance().currentUser?.uid
                    if (userId != null) {
                        fetchUserDataAndProceed(userId)
                    } else {
                        Toast.makeText(this, "Login successful, but UID not found.", Toast.LENGTH_SHORT).show()
                    }
                }
                is Resource.Error -> {
                    Toast.makeText(this, resource.message, Toast.LENGTH_SHORT).show()
                }
                else -> {}
            }
        }
    }

    private fun fetchUserDataAndProceed(userId: String) {
        firestore.collection("users").document(userId).get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val username = document.getString("username")
                    val email = document.getString("email")
                    Log.d("Firebase", "User data: Username = $username, Email = $email")

                    // Pindah ke MainActivity dengan membawa data user (opsional)
                    val intent = Intent(this, MainActivity::class.java)
                    intent.putExtra("username", username)
                    intent.putExtra("email", email)
                    startActivity(intent)
                    finish()
                } else {
                    Toast.makeText(this, "User data not found in Firestore.", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to fetch user data: ${it.message}", Toast.LENGTH_SHORT).show()
            }
    }
}

//        firebaseViewModel.loginState.observe(this) { resource ->
//            when (resource) {
//                is Resource.Loading -> {
//                    Log.d("Firebase User Authentication","Mengirim Username Password...")
//                }
//                is Resource.Success -> {
//                    Log.d("Firebase User Authetication","Halo ${firebaseViewModel.getCurrentUser().toString()}")
//                    val user = resource.data
//                    val editor = sharPref.edit()
//
//                    //Tidak perlu lagi, karena sudah dihandle oleh FirebaseAuth.getInstance().currentUser
//                    //editor.putString("isLogin", "1")
//
//                    editor.putString("username", user?.username)
//                    editor.apply()
//
//                    val intent = Intent(this, MainActivity::class.java)
//                    startActivity(intent)
//                    finish()
//                }
//                is Resource.Error -> {
//                    Toast.makeText(this, resource.message, Toast.LENGTH_SHORT).show()
//                }
//
//                else -> {}
//            }
//        }
//    }
//}

//            //ambil key dari Registrasi yang bagian editor.putString("username", a) -->misal
//            val storedUsername = sharPref.getString("username", null)
//            val storedPassword = sharPref.getString("password", null)
//
//            val inputUsernameText = inputUsernameL.text.toString()
//            val inputPasswordText = inputPasswordL.text.toString()
//
//
//            if (inputUsernameText == storedUsername && inputPasswordText == storedPassword) {
//                btnLogin.setBackgroundColor(Color.parseColor("#4A90E2"))
//                //melakukan set flag isLogin-->digunakan agar saat close app, langsung menampilkan MainActivity, tidak perlu login. Jika logout, baru tetap harus melakukan login
//                val editor = sharPref.edit()
//                editor.putString("isLogin", "1")
//                editor.apply()
//                //
//                Toast.makeText(this, "Login Sukses", Toast.LENGTH_SHORT).show()
//                val i = Intent(this, com.example.kelompokmindease_3tia.basic_api.ui.view.main.MainActivity::class.java)
//                //harus tambahkan bagian i.put extra agar saat ke main activity tidak null usernamenya
//                i.putExtra("username", inputUsernameText) //"name": username didapatkan dari hasil key sharedpreferences di put string.
//                startActivity(i)
//                finish()
//                // Lakukan navigasi kondisi
//            } else {
//                val view = this.findViewById<View>(android.R.id.content)
//                val snackbar = Snackbar.make(view, "Username dan password salah. Silahkan registrasi", Snackbar.LENGTH_LONG)
//                snackbar.show()
////                val toast= Toast.makeText(this, "Username atau password salah.Silahkan registrasi", Toast.LENGTH_SHORT)
////                toast.show()
//            }



//        btnLogin.setOnClickListener {
//            val a = inputUsernameL.text.toString()
//            val b = inputPasswordL.text.toString()
//
//            if (a == b ) {
//                //set username ke shared preferences
//                val editor=sharPref.edit()
//                editor.putString("username", a)
//                editor.putString("password", b)
//                editor.apply()
//                //Pemanggilan intent untuk berpindah ke Main Activity
//                val i = Intent(this, MainActivity::class.java)
//                //meletakkan nama  ID inputUsername yaitu a agar saat main activity bisa diambil data inputannya
//                i.putExtra("inputUsername", a)
//                startActivity(i)
//                finish()
//            } else {
//                //penggunaan toast untuk pop up
//                Toast.makeText(this, "Username dan password salah", Toast.LENGTH_LONG).show()
//            }
//        }
//        btnLogin.setOnClickListener{
//            val a= inputUsername.text
//            val b= inputPassword.text
//            val info ="Username : "+a+" | Password: "+b
//
//            Toast.makeText(this, info,Toast.LENGTH_LONG).show()
//        }


        //pertemuan 4 yg masih blm ada button registrasi
//        btnLogin.setOnClickListener {
//            val a = inputUsername.text.toString()
//            val b = inputPassword.text.toString()
//            if (a ==sharPref ) {
////                //set username ke shared preferences
////                val editor=sharPref.edit()
////                editor.putString("username", a)
////                editor.putString("password", b)
////                editor.apply()
//
//                //Pemanggilan intent untuk berpindah ke Main Activity
//                val i = Intent(this, MainActivity::class.java)
//                //meletakkan nama  ID inputUsername yaitu a agar saat main activity bisa diambil data inputannya
//                //i.putExtra("inputUsername", a)
//                startActivity(i)
//                finish()
//            } else {
//                //penggunaan toast untuk pop up
//                Toast.makeText(this, "Username dan password salah", Toast.LENGTH_LONG).show()
//            }
//        }
