package com.example.kelompokmindease_3tia.basic_api.ui.view

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_api.ui.view.welcome_screen.WelcomeScreenActivity
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class IntroActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_intro)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        lifecycleScope.launch{
            delay(1500)


            val w=Intent(this@IntroActivity, WelcomeScreenActivity::class.java)
            val i=Intent(this@IntroActivity, LoginActivity::class.java)
            startActivity(i)
            startActivity(w)
            finish()
        }
    }
}
