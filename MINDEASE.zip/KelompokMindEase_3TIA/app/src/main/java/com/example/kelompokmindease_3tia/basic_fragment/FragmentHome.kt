package com.example.kelompokmindease_3tia.basic_fragment

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.kelompokmindease_3tia.basic_api.ui.view.LoginActivity
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.SecondActivity
import com.example.kelompokmindease_3tia.basic_api.ui.view.main.home.NotifikasiHomeActivity

class FragmentHome : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        // Deklarasi/inisialisasi variabel
        val input1: EditText = view.findViewById(R.id.input1)
        val button1: Button = view.findViewById(R.id.button1)
        val result1: TextView = view.findViewById(R.id.result1)
        val input2: EditText = view.findViewById(R.id.input2)
        val button2: Button = view.findViewById(R.id.button2)
        val result2: TextView = view.findViewById(R.id.result2)
        val btnNext: Button = view.findViewById(R.id.btnNext)
        val welcome: TextView = view.findViewById(R.id.welcome)
        val btnLogout: Button = view.findViewById(R.id.btnLogout)
        val notif: ImageView = view.findViewById(R.id.imageNotif)

        val sharPref = requireActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val username = sharPref.getString("username", null) // Ambil username dari SharedPreferences
        welcome.text = "Welcome, $username!"

        button1.setOnClickListener {
            val x = input1.text.toString()
            val y = x.toInt() * x.toInt()
            result1.text = y.toString()
        }

        button2.setOnClickListener {
            val a = input2.text.toString()
            val b = result1.text.toString().toInt() * a.toInt()
            result2.text = b.toString()
        }

        btnNext.setOnClickListener {
            val i = Intent(requireActivity(), SecondActivity::class.java)
            i.putExtra("name", "Agnes Felicia")
            startActivity(i)
        }

        btnLogout.setOnClickListener {
            val editor = sharPref.edit()
            editor.clear()
            editor.apply()
            val i = Intent(requireActivity(), LoginActivity::class.java)
            i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(i)
            requireActivity().finish()
        }

        notif.setOnClickListener {
            val i = Intent(requireActivity(), NotifikasiHomeActivity::class.java)
            startActivity(i)
        }

        return view
    }
}