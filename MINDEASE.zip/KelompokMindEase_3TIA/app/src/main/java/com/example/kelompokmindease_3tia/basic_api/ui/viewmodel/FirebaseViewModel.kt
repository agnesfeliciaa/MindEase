package com.example.kelompokmindease_3tia.basic_api.ui.viewmodel

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kelompokmindease_3tia.basic_api.data.model.User
import com.example.kelompokmindease_3tia.basic_api.data.repository.FirebaseRepository
import com.example.kelompokmindease_3tia.basic_api.utils.NetworkUtils
import com.example.kelompokmindease_3tia.basic_api.utils.Resource
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.launch

class FirebaseViewModel(private val repository: FirebaseRepository) : ViewModel() {
    val registerState = MutableLiveData<Resource<Boolean>>()
    val loginState = MutableLiveData<Resource<FirebaseUser>>()

    fun register(user: User) {
        viewModelScope.launch {
            registerState.value = Resource.Loading()
            try {
                val result = repository.register(user)
                registerState.value = if (result) Resource.Success(true) else Resource.Error("Registration failed")
            } catch (e: Exception) {
                registerState.value = Resource.Error(e.message ?: "Error occurred")
            }
        }
    }

    fun login(email: String, password: String) {
        viewModelScope.launch {
            loginState.value = Resource.Loading()
            try {
                val user = repository.login(email, password)
                loginState.value = user?.let { Resource.Success(it) } ?: Resource.Error("Login failed")
            } catch (e: Exception) {
                loginState.value = Resource.Error(e.message ?: "Error occurred")
            }
        }
    }
}


//import android.content.Context
//import androidx.lifecycle.LiveData
//import androidx.lifecycle.MutableLiveData
//import androidx.lifecycle.ViewModel
//import androidx.lifecycle.viewModelScope
//import com.example.kelompokmindease_3tia.basic_api.data.model.User
//import com.example.kelompokmindease_3tia.basic_api.data.repository.FirebaseRepository
//import com.example.kelompokmindease_3tia.basic_api.utils.NetworkUtils
//import com.example.kelompokmindease_3tia.basic_api.utils.Resource
//import kotlinx.coroutines.launch
//
//class FirebaseViewModel(private val repository: FirebaseRepository) : ViewModel() {
//
//    private val _loginState = MutableLiveData<Resource<User>>()
//    val loginState: LiveData<Resource<User>> = _loginState
//
//    fun login(context: Context, email: String, password: String) {
//        if (NetworkUtils.isNetworkAvailable(context)) {
//            _loginState.value = Resource.Loading() // Set state ke Loading
//
//            viewModelScope.launch {
//                try {
//                    val user = repository.login(email, password)
//                    if (user!=null) {
//                        _loginState.value = Resource.Success(user)
//                    } else {
//                        _loginState.value = Resource.Error("Login gagal. Periksa kembali kredensial Anda.")
//                    }
//                } catch (e: Exception) {
//                    _loginState.value = Resource.Error(e.message ?: "Terjadi kesalahan saat login")
//                }
//            }
//        } else {
//            _loginState.postValue(Resource.Error("No internet connection"))
//        }
//    }
//
//    fun getCurrentUser() = repository.getCurrentUser()
//}