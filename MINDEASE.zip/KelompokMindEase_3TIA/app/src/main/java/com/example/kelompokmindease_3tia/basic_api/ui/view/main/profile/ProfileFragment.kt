package com.example.kelompokmindease_3tia.basic_api.ui.view.main.profile

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.appcompat.app.AlertDialog
import com.example.kelompokmindease_3tia.R
import com.example.kelompokmindease_3tia.basic_api.ui.view.LoginActivity
import com.example.kelompokmindease_3tia.databinding.FragmentProfileBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private val firestore = FirebaseFirestore.getInstance()
    private lateinit var pp: ImageView // ImageView di Fragment Profile

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentProfileBinding.inflate(inflater, container, false)


        binding.textSignOut.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Keluar")
                .setMessage("Apakah Anda yakin ingin keluar?")
                // Kondisi YES (pilih Ya)
                .setPositiveButton("Ya") { dialogInterface, which ->
                    dialogInterface.dismiss()
                    performSignOut() // Panggil fungsi untuk sign-out
                }
                // Kondisi jika NO (pilih Batal)
                .setNegativeButton("Batal", null)
                .show()
        }

        binding.fab.setOnClickListener {
            val i = Intent(requireActivity(), EditProfileActivity::class.java)
            startActivity(i)
        }

        binding.perangkatProfile.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Informasi Perangkat")
                .setMessage("Nama Perangkat: OPPO A5 2020\nVersi: Pita dasar & kernel\nVersi colorOS: V7.1\nVersi Android: 10\nProcessor: Qualcomm®Snapdragon™665\nRAM: 3,00GB\nPenyimpanan Perangkat: 64,0 GB(Total)\nInformasi Hukum: Perjanjian Pengguna, Kebijakan Privasi, dan Lainnya\nModel: CPH1931\nStatus Kartu SIM: SIM 1 = SIM1\nStatus: IMEI&IP")
                // Kondisi jika NO (pilih Batal)
                .setNegativeButton("Tutup", null)
                .show()
        }

        binding.pengaturanProfile.setOnClickListener {
            val i = Intent(requireActivity(), PengaturanActivity::class.java)
            startActivity(i)
        }

//        return view
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        pp = view.findViewById(R.id.pp) // Inisialisasi ImageView
        // Ambil data pengguna dari Firebase Firestore
        fetchUserProfile()
        // Ambil gambar yang disimpan di SharedPreferences
        val sharedPreferences =
            requireContext().getSharedPreferences("ProfilePrefs", Context.MODE_PRIVATE)
        val selectedImageResId = sharedPreferences.getInt("selectedImage", -1)

        if (selectedImageResId != -1) {
            pp.setImageResource(selectedImageResId) // Tampilkan gambar di ImageView
        }

    }

    private fun fetchUserProfile() {
        val currentUser = FirebaseAuth.getInstance().currentUser

        if (currentUser != null) {
            val userId = currentUser.uid

            // Ambil data dari Firestore berdasarkan UID
            firestore.collection("users").document(userId).get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val username = document.getString("username")
                        val email = document.getString("email")
                        val profileImageUrl =
                            document.getString("profileImageUrl") // Jika ada foto profil
                        val phone = document.getString("phone")

                        // Set data ke UI
                        binding.namaProfil.text = username
                        binding.emailProfil.text = email
                        binding.phoneProfil.text = phone

                        // Jika ada URL foto profil, Anda bisa menggunakan library seperti Glide untuk memuatnya
                        // Contoh: Glide.with(this).load(profileImageUrl).into(pp)
                    } else {
                        binding.namaProfil.text = "Nama tidak ditemukan"
                        binding.emailProfil.text = "Email tidak ditemukan"
                        binding.phoneProfil.text = "Nomor tidak ditemukan"
                    }
                }
                .addOnFailureListener {
                    binding.namaProfil.text = "Gagal memuat data"
                    binding.emailProfil.text = "Gagal memuat data"
                    binding.phoneProfil.text = "Gagal memuat data"
                }
        } else {
            // User belum login, arahkan ke LoginActivity
            val intent = Intent(requireActivity(), LoginActivity::class.java)
            startActivity(intent)
            requireActivity().finish()
        }
    }

    private fun performSignOut() {
        FirebaseAuth.getInstance().signOut()

        // Arahkan ke LoginActivity setelah logout
        val intent = Intent(requireActivity(), LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        requireActivity().finish()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}


//        val view = inflater.inflate(R.layout.fragment_profile, container, false)

//        val btnLogout: Button = view.findViewById(R.id.btnLogout)
//        val sharPref = requireActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
//        btnLogout.setOnClickListener {
//            val editor = sharPref.edit()
//            editor.clear()
//            editor.apply()
//            val i = Intent(requireActivity(), LoginActivity::class.java)
//            i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
//            startActivity(i)
//            requireActivity().finish()
//        }

//sharPref = requireActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)

//        binding.textSignOut.setOnClickListener{
//            val editor = sharPref.edit()
//            editor.clear()
//            editor.apply()
//
//            FirebaseAuth.getInstance().signOut()
//
//            val i = Intent(requireActivity(), LoginActivity::class.java)
//            i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
//            startActivity(i)
//            requireActivity().finish()
//        }
