package com.example.kelompokmindease_3tia.quiz_1.fragment_how_to

import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter

class HowToAdapter (
    activity: HowToActivity,
    private val fragments: List<Fragment>
): FragmentStateAdapter(activity){


    override fun getItemCount():Int{
        return fragments.size
    }
    override fun createFragment(position:Int): Fragment {
        return fragments[position]
    }


}
