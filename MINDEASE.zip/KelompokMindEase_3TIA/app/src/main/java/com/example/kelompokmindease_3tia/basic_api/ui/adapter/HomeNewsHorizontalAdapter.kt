package com.example.kelompokmindease_3tia.basic_api.ui.adapter
import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.kelompokmindease_3tia.basic_api.data.model.HomeNewsHorizontalModel
import com.example.kelompokmindease_3tia.databinding.HomeNewItemHorizontalBinding
import com.squareup.picasso.Picasso
class HomeNewsHorizontalAdapter(
    private var mList: List<HomeNewsHorizontalModel>,
    private val onItemClick: (String) -> Unit  // Menambahkan parameter callback untuk menangani klik
) : RecyclerView.Adapter<HomeNewsHorizontalAdapter.ViewHolder>() {

    fun updateData(newItems: List<HomeNewsHorizontalModel>) {
        mList = newItems
        notifyDataSetChanged()
    }

    class ViewHolder(val binding: HomeNewItemHorizontalBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = HomeNewItemHorizontalBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = mList[position]

        // Memuat gambar (gunakan Picasso jika URL)
        if (item.imageUrl is String) {
            Picasso.get().load(item.imageUrl as String).into(holder.binding.newsHoriImage)
        } else if (item.imageUrl is Int) {
            holder.binding.newsHoriImage.setImageResource(item.imageUrl as Int)
        }

        // Set text dan warna latar belakang
        holder.binding.newsHoriTitle.text = item.title
        holder.binding.newsHoriIsi.text = item.isi
        holder.binding.background.setBackgroundColor(Color.parseColor(item.background))
        holder.binding.layoutIsi.setBackgroundColor(Color.parseColor(item.backgroundIsi))

        // Menangani klik pada item untuk membuka URL
        holder.binding.root.setOnClickListener {
            onItemClick(item.url)  // Mengirim URL ke callback untuk membuka WebView
        }
    }

    override fun getItemCount(): Int {
        return mList.size
    }
}

//class HomeNewsHorizontalAdapter(
//
////    private val mList:List<HomeNewsHorizontalModel>
//    private var mList:List<HomeNewsHorizontalModel>,
//    //private val onItemClick: (String) -> Unit // Tambahkan parameter onClick
//):RecyclerView.Adapter<HomeNewsHorizontalAdapter.ViewHolder>(){
//
//    fun updateData(newItems: List<HomeNewsHorizontalModel>){
//        mList = newItems
//        notifyDataSetChanged()
//    }
//
//    class ViewHolder(val binding:HomeNewItemHorizontalBinding) : RecyclerView.ViewHolder(binding.root)
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
////        val view=LayoutInflater.from(parent.context).inflate(R.layout.home_new_item_horizontal, parent, false)
////        return ViewHolder(view)
//        val  binding= HomeNewItemHorizontalBinding.inflate(LayoutInflater.from(parent.context), parent, false)
//        return ViewHolder(binding)
//    }
//
//    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//        val item = mList[position]
//
//        // Cek tipe `imagaUrl` untuk menentukan cara memuat gambar
//        if (item.imageUrl is String) {
//            // Memuat URL eksternal dengan Picasso
//            Picasso.get().load(item.imageUrl as String).into(holder.binding.newsHoriImage)
//        } else if (item.imageUrl is Int) {
//            // Memuat resource drawable lokal
//            holder.binding.newsHoriImage.setImageResource(item.imageUrl as Int)
//        }
//        //set description based on item.description
//        holder.binding.newsHoriTitle.text = item.title
//        holder.binding.newsHoriIsi.text = item.isi
////        atur warna background
//        holder.binding.background.setBackgroundColor(Color.parseColor(item.background))
//        holder.binding.layoutIsi.setBackgroundColor(Color.parseColor(item.backgroundIsi))
//        //orinttt cobaa printtt
//        //println("Loading item pada position = $position")
//    }
//
////    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HomeNewsHorizontalAdapter.ViewHolder {
////        val view=LayoutInflater.from(parent.context).inflate(R.layout.home_new_item_horizontal, parent, false)
////        return ViewHolder(view)
////    }
////
////    override fun onBindViewHolder(holder: HomeNewsHorizontalAdapter.ViewHolder, position: Int) {
////        val item = mList[position]
////        //set image based on item.imageUrl -->library picasso
//////        Picasso.get().load(item.imagaUrl).into(holder.newsHoriImage)
////
////        // gambar dari drawable
////        holder.newsHoriImage.setImageResource(item.imagaUrl as Int)
////        //set description based on item.description
////        holder.newsHoriTitle.text = item.title
////        holder.newsHoriIsi.text = item.isi
//////        atur warna background
////        holder.newsHoriBackground.setBackgroundColor(Color.parseColor(item.background))
////        holder.newsHoriIsiBackground.setBackgroundColor(Color.parseColor(item.backgroundIsi))
////
////    }
//
//    override fun getItemCount(): Int {
//        return mList.size
//    }
////    class ViewHolder(ItemView: View) :RecyclerView.ViewHolder(ItemView){
////        val newsHoriTitle:TextView=itemView.findViewById(R.id.newsHoriTitle)
////        val newsHoriImage:ImageView=itemView.findViewById(R.id.newsHoriImage)
////        val newsHoriIsi:TextView=itemView.findViewById(R.id.newsHoriIsi)
////        val newsHoriBackground:ConstraintLayout=itemView.findViewById(R.id.background)
////        val newsHoriIsiBackground:ConstraintLayout=itemView.findViewById(R.id.layoutIsi)
////    }
//}