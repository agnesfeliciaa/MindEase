package com.example.kelompokmindease_3tia.basic_api.ui.view.main.meditasi

import android.content.Intent
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.kelompokmindease_3tia.R
import java.io.IOException

class PutarTidurLebihNyenyakActivity : AppCompatActivity() {

    var mediaPlayer: MediaPlayer? = null
    private lateinit var btnPlayLagu: ImageView
    private lateinit var btnPauseLagu: ImageView
    private lateinit var imgBack :ImageView
    private lateinit var seekBar: SeekBar
    private lateinit var textDurasiSekarang: TextView
    private lateinit var textTotalDurasi: TextView
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_putar_tidur_lebih_nyenyak)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        btnPlayLagu = findViewById(R.id.imgPlayLagu)
        btnPauseLagu = findViewById(R.id.imgPauseLagu)
        imgBack=findViewById(R.id.imgBack)
        seekBar = findViewById(R.id.seekbar)
        textDurasiSekarang = findViewById(R.id.textDurasiSekarang)
        textTotalDurasi = findViewById(R.id.textTotalDurasi)
        val btnBackLagu: ImageView = findViewById(R.id.imgBackLagu)
        val btnNextLagu: ImageView = findViewById(R.id.imgNextLagu)

        btnNextLagu.visibility = View.GONE

        playAudio()

        btnPlayLagu.setOnClickListener {
            playAudio()
        }

        btnPauseLagu.setOnClickListener {
            pauseAudio()
        }
        //btn back
        imgBack.setOnClickListener(){
            finish()
        }

        btnBackLagu.setOnClickListener {
            pauseAudio()
            val i = Intent(this, PutarStressdanKecemasanActivity::class.java)
            startActivity(i)
            finish()
        }
    }

    private fun playAudio() {
        btnPlayLagu.visibility = View.GONE
        btnPauseLagu.visibility = View.VISIBLE

        if (mediaPlayer == null) {
            val audioUrl =
                "https://drive.google.com/uc?export=download&id=1MtvdnLluYFNG27RBUFSqPxBVYYCysjQs"
            mediaPlayer = MediaPlayer().apply {
                setAudioStreamType(AudioManager.STREAM_MUSIC)
                setDataSource(audioUrl)
                prepareAsync()
                setOnPreparedListener { mp ->
                    mp.start()

                    // Atur durasi total
                    val totalDuration = mp.duration
                    textTotalDurasi.text = formatTime(totalDuration)

                    // Atur SeekBar
                    seekBar.max = totalDuration
                    updateSeekBar()
                }
            }
            Toast.makeText(this, "Audio started playing", Toast.LENGTH_SHORT).show()
        } else {
            // Lanjutkan pemutaran dari posisi terakhir
            mediaPlayer?.start()
            updateSeekBar()
            Toast.makeText(this, "Audio resumed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun pauseAudio() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.pause()
            }
        }
        btnPauseLagu.visibility = View.GONE
        btnPlayLagu.visibility = View.VISIBLE
    }

    private fun updateSeekBar() {
        mediaPlayer?.let { mp ->
            seekBar.progress = mp.currentPosition
            textDurasiSekarang.text = formatTime(mp.currentPosition)

            // Jalankan pembaruan setiap 1 detik
            handler.postDelayed({ updateSeekBar() }, 1000)
        }

        // Tambahkan listener untuk SeekBar
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    mediaPlayer?.seekTo(progress)
                    textDurasiSekarang.text = formatTime(progress)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
    }

    private fun formatTime(duration: Int): String {
        val minutes = duration / 1000 / 60
        val seconds = duration / 1000 % 60
        return String.format("%02d:%02d", minutes, seconds)
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
        mediaPlayer = null
        handler.removeCallbacksAndMessages(null)
    }
}